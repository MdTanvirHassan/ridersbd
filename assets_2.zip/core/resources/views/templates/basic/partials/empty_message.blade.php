<div class="empty-message">
    <img src="{{ getImage('assets/images/empty.png') }}" alt="">
    <div class="message">{{ $message }}</div>

</div>
