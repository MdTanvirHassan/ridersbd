<div class="hero-section section-bg py-4">
    <div class="container">
        <ul class="breadcrumb">

            @stack('breadcrumb-plugins')

            <li>@lang(__($page_title))</li>
           
        </ul>
    </div>
</div>
