<?php $__env->startSection('panel'); ?>
    <div class="row mb-none-30">

        <div class="col-lg-12 col-md-12 mb-30">
            <div class="card">
                <div class="card-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Site Title'); ?> </label>
                            </div>
                            <div class="col-md-10">
                                <input class="form-control form-control-lg" type="text" name="sitename" value="<?php echo e($general->sitename); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Preloader Title'); ?> </label>
                            </div>
                            <div class="col-md-10">
                                <input class="form-control form-control-lg" type="text" name="preloader_title" value="<?php echo e($general->preloader_title); ?>">
                                <small class="text--small text--danger">
                                    <i class="las la-info-circle"></i>
                                    <?php echo app('translator')->get('Maximum 12 characters are allowed'); ?>
                                </small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"><?php echo app('translator')->get('Currency'); ?></label>
                            </div>
                            <div class="col-md-10">
                                <input class="form-control  form-control-lg" type="text" name="cur_text" value="<?php echo e(__($general->cur_text)); ?>">

                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"><?php echo app('translator')->get('Currency Symbol'); ?></label>
                            </div>
                            <div class="col-md-10">
                                <input class="form-control  form-control-lg" type="text" name="cur_sym" value="<?php echo e(__($general->cur_sym)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Site Base Color'); ?></label>
                            </div>
                            <div class="col-md-10">
                                <div class="input-group">
                                    <span class="input-group-addon ">
                                        <input type='text' class="form-control  form-control-lg colorPicker"
                                            value="<?php echo e($general->base_color); ?>"/>
                                    </span>
                                    <input type="text" class="form-control form-control-lg colorCode" name="base_color" value="<?php echo e($general->base_color); ?>"/>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2">
                                <label class="font-weight-bold"> <?php echo app('translator')->get('Site Secondary Color'); ?></label>
                            </div>
                            <div class="col-md-10">
                                <div class="input-group">
                                <span class="input-group-addon">
                                    <input type='text' class="form-control form-control-lg colorPicker"
                                           value="<?php echo e($general->secondary_color); ?>"/>
                                </span>
                                    <input type="text" class="form-control form-control-lg colorCode" name="secondary_color" value="<?php echo e($general->secondary_color); ?>"/>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">

                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold mr-1">
                                            <?php echo app('translator')->get('Cash On Delivery'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="cod" <?php if($general->cod): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold mr-1">
                                            <?php echo app('translator')->get('User Registration'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="registration" <?php if($general->registration): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>


                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold">
                                            <?php echo app('translator')->get('Email Verification'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="ev" <?php if($general->ev): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold">
                                            <?php echo app('translator')->get('Email Notification'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="en" <?php if($general->en): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold">
                                            <?php echo app('translator')->get('SMS Verification'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="sv" <?php if($general->sv): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-4 col-sm-3">
                                <div class="form-group row">
                                    <div class="col-md-12">
                                        <label class="font-weight-bold">
                                            <?php echo app('translator')->get('SMS Notification'); ?>
                                        </label>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="switch">
                                            <input type="checkbox" name="sn" <?php if($general->sn): ?> checked <?php endif; ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn--success btn-block btn-lg"><?php echo app('translator')->get('Update'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/admin/js/spectrum.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/spectrum.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('style'); ?>
    <style>
        .sp-replacer {
            padding: 0;
            border: none;
            border-radius: 5px 0 0 5px;
        }

        .sp-preview {
            width: 100px;
            height: 46px;
            border: 0;
        }

        .sp-preview-inner {
            width: 110px;
        }

        .sp-dd {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        (function ($) {
            $('.colorPicker').spectrum({
                color: $(this).data('color'),
                change: function (color) {
                    $(this).parent().siblings('.colorCode').val(color.toHexString().replace(/^#?/, ''));
                }
            });

            $('.colorCode').on('input', function () {
                var clr = $(this).val();
                $(this).parents('.input-group').find('.colorPicker').spectrum({
                    color: clr,
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/setting/general_setting.blade.php ENDPATH**/ ?>