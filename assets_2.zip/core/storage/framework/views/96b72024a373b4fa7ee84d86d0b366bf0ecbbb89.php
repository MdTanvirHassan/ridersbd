<?php $__env->startSection('content'); ?>

<!-- Product Single Section Starts Here -->
<div class="category-section padding-bottom-half padding-top oh">
    <div class="container">
        <div class="row product-details-wrapper">
            <div class="col-lg-5 variant-images">
                <div class="sync1 owl-carousel owl-theme">
                    <?php if($images->count() == 0): ?>
                        <div class="thumbs">
                            <img class="zoom_img"
                                src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="thumbs">
                            <img class="zoom_img"
                                src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <div class="sync2 owl-carousel owl-theme mt-2">
                    <?php if($images->count() > 1): ?>
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="thumbs">
                            <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>


            <div class="col-lg-7">
                <div class="product-details-content product-details">
                    <h4 class="title"><?php echo e(__($product->name)); ?></h4>

                    <div class="ratings-area justify-content-between">
                        <div class="ratings">
                            <?php echo __(display_avg_rating($product->reviews)) ?>
                        </div>
                        <span class="ml-2 mr-auto">(<?php echo e(__($product->reviews->count())); ?>)</span>
                    </div>
                    <a href="#">
                        <span class="elementor-icon-list-icon">
                            <i aria-hidden="true" class="far fa-file-pdf text-danger"></i>						
                        </span>
                         <span class="text-dark">Product Brochure</span>
                    </a>
                    <?php if($product->show_in_frontend && $product->track_inventory): ?>
                    <?php $quantity = $product->stocks->sum('quantity'); ?>
                    <div class="badge badge--<?php echo e($quantity>0?'success':'danger'); ?> stock-status"><?php echo app('translator')->get('In Stock'); ?> (<span class="stock-qty"><?php echo e($quantity); ?></span>)</div>
                    <?php endif; ?>

                    <div class="price">
                        <?php if($discount > 0): ?>
                            <?php echo e($general->cur_sym); ?><span class="special_price"><?php echo e(getAmount($product->base_price - $discount)); ?></span>
                            <del><?php echo e($general->cur_sym); ?></del><del class="price-data"><?php echo e(getAmount($product->base_price)); ?></del>
                        <?php else: ?>
                            <?php echo e($general->cur_sym); ?><span class="price-data"><?php echo e(getAmount($product->base_price)); ?></span>
                        <?php endif; ?>
                    </div>

                    <p>
                        <?php echo __($product->summary) ?>
                    </p>

                    <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php $attr_data = getProuductAttributes($product->id, $attr->product_attribute_id); ?>
                    <?php if($attr->productAttribute->type==1): ?>
                    <div class="product-size-area attr-area">
                        <span class="caption"><?php echo e(__($attr->productAttribute->name_for_user)); ?></span>
                        <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-single-size attribute-btn" data-type="1" data-discount=<?php echo e($discount); ?> data-ti="<?php echo e($product->track_inventory); ?>" data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>"  data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e($product->base_price); ?>" ><?php echo e($data->value); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <?php if($attr->productAttribute->type==2): ?>
                    <div class="product-color-area attr-area">
                        <span class="caption"><?php echo e(__($attr->productAttribute->name_for_user)); ?></span>
                        <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-single-color attribute-btn" data-type="2" data-ti="<?php echo e($product->track_inventory); ?>" data-discount=<?php echo e($discount); ?> data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>" data-bg="<?php echo e($data->value); ?>" data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e($product->base_price); ?>"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php endif; ?>
                    <?php if($attr->productAttribute->type==3): ?>
                    <div class="product-color-area attr-area">
                        <span class="caption"><?php echo e(__($attr->productAttribute->name_for_user)); ?></span>
                        <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product-single-color attribute-btn bg_img" data-type="3" data-ti="<?php echo e($product->track_inventory); ?>" data-discount=<?php echo e($discount); ?> data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>" data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e($product->base_price); ?>" data-background="<?php echo e(getImage(imagePath()['attribute']['path'].'/'. @$data->value)); ?>">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!--<div class="cart-and-coupon mt-3">-->

                    <!--    <div class="attr-data">-->
                    <!--    </div>-->

                    <!--    <div class="cart-plus-minus quantity">-->
                    <!--        <div class="cart-decrease qtybutton dec">-->
                    <!--            <i class="las la-minus"></i>-->
                    <!--        </div>-->
                    <!--        <input type="number" name="quantity" step="1" min="1" value="1" class="integer-validation">-->
                    <!--        <div class="cart-increase qtybutton inc">-->
                    <!--            <i class="las la-plus"></i>-->
                    <!--        </div>-->
                    <!--    </div>-->

                    <!--    <div class="add-cart">-->
                    <!--        <button type="submit" class="cmn-btn cart-add-btn" data-id="<?php echo e($product->id); ?>"><?php echo app('translator')->get('Add To Cart'); ?></button>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <div class="specification-wrapper mb-3">
                    <?php if($product->specification): ?>
                        <h5 class="title"><?php echo app('translator')->get('Specification'); ?></h5>
                        <div class="table-wrapper">
                            <table class="specification-table">
                                <?php $__currentLoopData = $product->specification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e(__($item['name'])); ?></th>
                                    <td><?php echo e(__($item['value'])); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    <?php else: ?>
                    <div class="alert cl-title alert--base" role="alert">
                        <?php echo app('translator')->get('No Specification For This Product'); ?>
                    </div>
                    <?php endif; ?>
                </div>
                    <div>
                        <p>
                            <b>
                                <?php echo app('translator')->get('Categories'); ?>:
                            </b>
                            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>"><?php echo e(__($category->name)); ?></a>
                                <?php if(!$loop->last): ?>
                                /
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                        
                        <!--<p>-->
                        <!--    <b><?php echo app('translator')->get('Model'); ?>:</b> <?php echo e(__($product->model)); ?>-->
                        <!--</p>-->
                        <p>
                            <b><?php echo app('translator')->get('Brand'); ?>:</b> <?php echo e(__($product->brand->name)); ?>

                        </p>

                        <!--<p>-->
                        <!--    <b><?php echo app('translator')->get('SKU'); ?>:</b> <span class="product-sku"><?php echo e($product->sku??__('Not Available')); ?></span>-->
                        <!--</p>-->

                        <p class="product-share">
                            <b><?php echo app('translator')->get('Share'); ?>:</b>
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url()->current())); ?>" title="<?php echo app('translator')->get('Facebook'); ?>">

                                <i class="fab fa-facebook"></i>
                            </a>

                            <a href="http://pinterest.com/pin/create/button/?url=<?php echo e(urlencode(url()->current())); ?>&description=<?php echo e(__($product->name)); ?>&media=<?php echo e(getImage('assets/images/product/'. @$product->main_image)); ?>" title="<?php echo app('translator')->get('Pinterest'); ?>">

                                <i class="fab fa-pinterest-p"></i>
                            </a>

                            <a href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo e(urlencode(url()->current())); ?>&amp;title=my share text&amp;summary=dit is de linkedin summary" title="<?php echo app('translator')->get('Linkedin'); ?>">

                                <i class="fab fa-linkedin"></i>
                            </a>

                            <a href="https://twitter.com/intent/tweet?text=<?php echo e(__($product->name)); ?>%0A<?php echo e(url()->current()); ?>" title="<?php echo app('translator')->get('Twitter'); ?>">

                                <i class="fab fa-twitter"></i>
                            </a>
                        </p>
                        <?php
                            $wCk = checkWishList($product->id);
                        ?>
                        <!--<p class="product-details-wishlist">-->
                        <!--    <b><?php echo app('translator')->get('Add To Wishlist'); ?>: </b>-->
                        <!--    <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk?'active':''); ?>" data-id="<?php echo e($product->id); ?>"><span class="wish-icon"></span></a>-->
                        <!--</p>-->

                        <?php if($product->meta_keywords): ?>
                        <p>
                            <b>
                                <?php echo app('translator')->get('Tags'); ?>:
                            </b>
                            <?php $__currentLoopData = $product->meta_keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href=""><?php echo e(__($tag)); ?></a><?php if(!$loop->last): ?>,<?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                        <?php endif; ?>
                    </div>

                </div>
                <!--  -->
                <!-- Button to trigger modal -->
                <div class="mt-5">
    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#interestModal">Yes, I am Interested</button>
</div>

<!-- Modal -->
<div class="modal fade" id="interestModal" tabindex="-1" role="dialog" aria-labelledby="interestModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <img decoding="async" class="hfe-site-logo-img elementor-animation-" src="https://ridersgroupbd.com/wp-content/uploads/2022/09/Riders-Star-Group-Ltd-300x260.png" alt="Riders group ltd" style="height: 50px; width:100px">
                <h6 class="modal-title" id="interestModalLabel" style="color:#fd7e14">Connect with "RIDERS Star Group Ltd."</h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form id="interestForm" action="<?php echo e(route('submitForm')); ?>" method="POST">

                    <?php echo csrf_field(); ?>
                    <input type="hidden" class="form-control" id="product_id" name="product_id" value="<?php echo e($product->id); ?>">


                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
                    </div>
                    <div class="form-group">
                        <label for="email">Your Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email">
                    </div>
                    <div class="form-group">
                        <label for="phone">Your Phone Number</label>
                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter your phone number">
                    </div>
                    <div class="form-group">
                        <label for="message">Your Message (optional)</label>
                        <textarea class="form-control" id="message" name="message" rows="3" placeholder="Enter your message (optional)"></textarea>
                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-warning">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</div>


<!--  -->
            </div>
        </div>
    </div>
</div>
<!-- Product Single Section Ends Here -->

<!-- Product Single Section Starts Here -->
<div class="products-description padding-bottom padding-top-half">
    <div class="container">

        <ul class="nav nav-tabs">
            <li>
                <a href="#description" class="active" data-toggle="tab"><?php echo app('translator')->get('Description'); ?></a>
            </li>

            <li>
                <a href="#specification" data-toggle="tab"><?php echo app('translator')->get('Specification'); ?></a>
            </li>

            <li>
                <a href="#video" data-toggle="tab"><?php echo app('translator')->get('Video'); ?></a>
            </li>

            <li>
                <a href="#reviews" data-toggle="tab"><?php echo app('translator')->get('Reviews'); ?>(<?php echo e(__($product->reviews->count())); ?>)</a>
            </li>

        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="description">
                <div class="description-item">
                    <?php if($product->description): ?>
                    <p>
                        <?php echo app('translator')->get($product->description); ?>
                    </p>

                    <?php else: ?>
                    <div class="alert cl-title alert--base" role="alert">
                        <?php echo app('translator')->get('No Description For This Product'); ?>
                    </div>
                    <?php endif; ?>
                </div>

                <?php if($product->extra_descriptions): ?>
                <div class="description-item">
                    <?php $__currentLoopData = $product->extra_descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h5><?php echo e(__($item['key'])); ?></h5>
                        <p>
                            <?php
                                echo __($item['value']);
                            ?>
                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php endif; ?>
            </div>
            <div class="tab-pane fade " id="specification">
                <div class="specification-wrapper">
                    <?php if($product->specification): ?>
                        <h5 class="title"><?php echo app('translator')->get('Specification'); ?></h5>
                        <div class="table-wrapper">
                            <table class="specification-table">
                                <?php $__currentLoopData = $product->specification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e(__($item['name'])); ?></th>
                                    <td><?php echo e(__($item['value'])); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    <?php else: ?>
                    <div class="alert cl-title alert--base" role="alert">
                        <?php echo app('translator')->get('No Specification For This Product'); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="tab-pane fade" id="video">
                <?php if(!empty($product->video_link)): ?>
                    <?php
                        $embedUrl = convertToEmbedUrl($product->video_link);
                    ?>
                    <iframe width="560" height="315" src="<?php echo e($embedUrl); ?>" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                <?php else: ?>
                    <div class="alert cl-title alert--base" role="alert">
                        <?php echo app('translator')->get('No Video For This Product'); ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="tab-pane fade" id="reviews">
                <div class="review-area">

                </div>
            </div>
        </div>
        <?php if($related_products): ?>
            <div class="related-products mt-5">
                <h5 class="title bold mb-3 mb-lg-4"><?php echo app('translator')->get('Related Products'); ?></h5>
                <div class="m--15 oh">
                    <div class="related-products-slider owl-carousel owl-theme">
                        <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        if($item->offer && $item->offer->activeOffer){
                            $discount_amount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                        }else $discount_amount = 0;

                        $wCk = checkWishList($item->id);
                        $cCk = checkCompareList($item->id);
                    ?>

                    <div class="product-item-2">
                        <div class="product-item-2-inner wish-buttons-in">
                            <ul class="wish-react">
                                <li>
                                <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="lar la-heart"></i></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="add-to-compare <?php echo e($cCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="las la-sync-alt"></i></a>
                                </li>
                            </ul>
                            <div class="product-thumb">
                                <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                                </a>
                            </div>

                            <div class="product-content">
                                <div class="product-before-content">
                                    <h6 class="title">
                                        <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e($item->name); ?></a>
                                    </h6>
                                    <div class="ratings-area justify-content-between">
                                        <div class="ratings">
                                            <?php echo __(display_avg_rating($item->reviews)) ?>
                                        </div>

                                        <span class="ml-2 mr-auto">(<?php echo e(__($item->reviews->count())); ?>)</span>
                                        <div class="price">
                                            <?php if($discount_amount > 0): ?>
                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount_amount, 2)); ?>

                                            <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                            <?php else: ?>
                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-after-content">
                                    <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                        <?php echo app('translator')->get('View'); ?>
                                    </button>
                                    <div class="price">
                                        <?php if($discount_amount > 0): ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount_amount, 2)); ?>

                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                        <?php else: ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    // $(document).ready(function() {
    //     $('#interestForm').on('submit', function(e) {
    //         e.preventDefault();
            
    //         // Collect form data
    //         var formData = {
    //             name: $('#name').val(),
    //             email: $('#email').val(),
    //             phone: $('#phone').val(),
    //             message: $('#message').val()
    //         };
            
    //         // Submit form data using AJAX
    //         $.ajax({
    //             type: 'POST',
    //             url: '<?php echo e(route("submitForm")); ?>',
    //             data: formData,
    //             success: function(data) {
    //                 console.log('Form submitted successfully');
    //                 console.log(data);
    //                 // Optionally, close the modal or show a success message
    //             },
    //             error: function(xhr, status, error) {
    //                 console.error('Error submitting form:', error);
    //                 console.error(xhr.responseText);
    //                 // Optionally, display an error message to the user
    //             }
    //         });
    //     });
    // });




    'use strict';
    (function($){
        var pid = '<?php echo e($product->id); ?>';
        load_data(pid);
        function load_data(pid, url="<?php echo e(route('product_review.load_more')); ?>") {
            $.ajax({
                url: url,
                method: "GET",
                data: { pid: pid },
                success: function (data) {
                    $('#load_more_button').remove();
                    $('.review-area').append(data);
                }
            });
        }
        $(document).on('click', '#load_more_button', function () {
            var id  = $(this).data('id');
            var url = $(this).data('url');
            $('#load_more_button').html(`<b><?php echo e(__('Loading')); ?> <i class="fa fa-spinner fa-spin"></i> </b>`);
            load_data(pid, url);
        });

    })(jQuery)

</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', ['seo_contents'=>@$seo_contents], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/product_details.blade.php ENDPATH**/ ?>