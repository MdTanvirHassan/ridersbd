<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 mb-30">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.frontend.sections.content', 'seo')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="data">
                        <input type="hidden" name="seo_image" value="1">
                        <div class="row">
                            <div class="col-xl-4">
                                <div class="form-group">
                                    <div class="image-upload">
                                        <div class="thumb">
                                            <div class="avatar-preview">
                                                <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['seo']['path'].'/'. @$seo->data_values->image,'600x315')); ?>)">
                                                    <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                                </div>
                                            </div>
                                            <div class="avatar-edit">
                                                <input type="file" class="profilePicUpload" name="image_input" id="profilePicUpload1" accept=".png, .jpg, .jpeg">
                                                <label for="profilePicUpload1" class="bg--success"><?php echo app('translator')->get('Upload Image'); ?></label>
                                                <small class="mt-2 text-facebook">
                                                    <?php echo app('translator')->get('Supported files: jpeg, jpg .'); ?> <?php echo app('translator')->get('Image will be resized into'); ?> <?php echo e(imagePath()['seo']['size']); ?>px
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-8 mt-xl-0 mt-4">
                                <div class="form-group row">
                                    <div class="col-md-3">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Meta Keywords'); ?></label>
                                    </div>
                                    <div class="col-md-9">
                                        <select name="keywords[]" class="form-control select2-auto-tokenize"  multiple="multiple" required>
                                            <?php if(@$seo->data_values->keywords): ?>
                                                <?php $__currentLoopData = $seo->data_values->keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option); ?>" selected><?php echo e(__($option)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                        <small class="text--small text-muted"> <i class="la la-exclamation-circle"></i> <?php echo app('translator')->get('Type , or hit enter to seperate keywords'); ?></small>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-md-3">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Meta Description'); ?></label>
                                    </div>
                                    <div class="col-md-9">
                                        <textarea name="description" rows="3" class="form-control" placeholder="<?php echo app('translator')->get('SEO Meta Description'); ?>" required><?php echo e(@$seo->data_values->description); ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-3">
                                        <label class=" font-weight-bold"><?php echo app('translator')->get('Social Title'); ?></label>
                                    </div>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Social Share Title'); ?>" name="social_title" value="<?php echo e(@$seo->data_values->social_title); ?>" required/>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-3">
                                        <label class=" font-weight-bold"><?php echo app('translator')->get('Social Description'); ?></label>
                                    </div>
                                    <div class="col-md-9">
                                        <textarea name="social_description" rows="3" class="form-control" placeholder="<?php echo app('translator')->get('Social Share  Meta Description'); ?>" required><?php echo e(@$seo->data_values->social_description); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Update'); ?></button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    (function ($) {
        "use strict";
        $('.select2-auto-tokenize').select2({
            dropdownParent: $('.card-body form'),
            tags: true,
            tokenSeparators: [',']
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/frontend/seo.blade.php ENDPATH**/ ?>