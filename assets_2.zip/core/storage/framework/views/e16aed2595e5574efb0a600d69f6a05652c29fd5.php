<!-- Category Section Starts Here -->
<div class="category-section padding-bottom-half">
    <div class="container">
        <div class="row justify-content-between">
            <?php if($top_categories->count()>0): ?>
                <div class="col-lg-6 padding-bottom-half padding-top-half">
                    <div class="section-header-2">
                        <h3 class="title"><?php echo app('translator')->get('Top Categories'); ?></h3>
                        <a href="<?php echo e(route('categories')); ?>" class="custom-button theme btn-sm"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                    <div class="m--10">
                        <div class="category-slider owl-theme owl-carousel">

                            <?php $__currentLoopData = $top_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cate-item">
                                    <a href="<?php echo e(route('products.category', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="cate-inner">
                                        <img src="<?php echo e(getImage(imagePath()['category']['path'].'/'.@$item->image, imagePath()['category']['size'])); ?>" alt="<?php echo app('translator')->get('products-category'); ?>">
                                        <span><?php echo e(__($item->name)); ?></span>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if($top_brands->count()>0): ?>
                <div class="col-lg-6 padding-bottom-half padding-top-half">
                    <div class="section-header-2">
                        <h3 class="title"><?php echo app('translator')->get('Top Brands'); ?></h3>
                        <a href="<?php echo e(route('brands')); ?>" class="custom-button theme btn-sm"><?php echo app('translator')->get('View All'); ?></a>
                    </div>
                    <div class="m--10">
                        <div class="category-slider owl-theme owl-carousel">
                            <?php $__currentLoopData = $top_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="cate-item">
                                    <a href="<?php echo e(route('products.brand', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="cate-inner">
                                        <img src="<?php echo e(getImage(imagePath()['brand']['path'].'/'.@$item->logo, imagePath()['brand']['size'])); ?>" alt="<?php echo app('translator')->get('products-category'); ?>">
                                        <span><?php echo e(__($item->name)); ?></span>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Category Section Ends Here -->
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/sections/top_categories_brands.blade.php ENDPATH**/ ?>