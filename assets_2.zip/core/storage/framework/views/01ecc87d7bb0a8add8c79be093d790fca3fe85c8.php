<?php $__env->startSection('content'); ?>
    <?php
        $content = getContent('contact_page.content', true);
    ?>

<!-- Contact Section Starts Here -->
<div class="contact-section padding-bottom padding-top oh position-relative">
    <div class="container">
        <div class="row justify-content-between align-items-center">
            <div class="col-lg-7">
                <?php if($content): ?>
                <div class="section-header mb-low left-style">
                    <h3 class="title"><?php echo app('translator')->get(@$content->data_values->title); ?></h3>
                    <p><?php echo app('translator')->get(@$content->data_values->description); ?></p>
                </div>
                <?php endif; ?>
                <form method="post" class="contact-form">
                    <?php echo csrf_field(); ?>
                    <div class="contact-group">
                        <label for="name"><?php echo app('translator')->get('Name'); ?></label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="form-control h-50" required>
                    </div>
                    <div class="contact-group">
                        <label for="email"><?php echo app('translator')->get('Email'); ?></label>
                        <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control h-50" required>
                    </div>

                    <div class="contact-group">
                        <label for="subject"><?php echo app('translator')->get('Subject'); ?></label>
                        <input type="text" name="subject" id="subject" value="<?php echo e(old('subject')); ?>" class="form-control h-50" required>

                    </div>
                    <div class="contact-group">
                        <label for="message"><?php echo app('translator')->get('Message'); ?></label>
                        <textarea name="message" id="message" class="form-control h-120" required><?php echo e(old('message')); ?></textarea>
                    </div>
                    <div class="contact-group mb-0 justify-content-end">
                        <button type="submit" class="cmn-btn h-50">
                            <?php echo app('translator')->get('Send Message'); ?>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-lg-5 d-none d-lg-block">
                <div class="contact--thumb">
                    <img src="<?php echo e(getImage('assets/images/frontend/contact_page/'. @$content->data_values->image, '800x964')); ?>" alt="<?php echo app('translator')->get('login-bg'); ?>">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact Section Ends Here -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/contact.blade.php ENDPATH**/ ?>