<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10">
            <div class="card-body">

                <div class="row justify-content-end">
                    <div class="col-lg-4 mb-3">
                        <form action="<?php echo e(request()->routeIs('admin.products.trashed') || request()->routeIs('admin.products.trashed.search')?route('admin.products.trashed.search'):route('admin.products.search')); ?>" method="GET" >
                            <div class="input-group has_append">
                                <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Search'); ?>..."
                                    value="<?php echo e(request()->search ?? ''); ?>">
                                <div class="input-group-append">
                                    <button class="btn btn--success" id="search-btn" type="submit"><i class="la la-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive--md table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Id'); ?></th>
                                <th><?php echo app('translator')->get('Thumbnail'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <th><?php echo app('translator')->get('In Stock'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Id">
                                    <?php echo e($products->firstItem() + $loop->index); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Thumbnail'); ?>">
                                    <div class="thumbnails d-inline-block">
                                        <div class="thumb">
                                            <a href="<?php echo e(getImage(imagePath()['product']['path'].  '/thumb_'. @$product->main_image, imagePath()['product']['size'])); ?>" class="image-popup">
                                                <img src="<?php echo e(getImage(imagePath()['product']['path']. '/thumb_'. @$product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                                            </a>
                                        </div>
                                    </div>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                    <a href="<?php echo e(route('admin.products.edit', [$product->id, slug($product->name)])); ?>"><span class="name mb-0"  onclick="<?php echo e($product->trashed()?'return false':''); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__($product->name)); ?>">
                                        <?php echo e(shortDescription($product->name, 50)); ?></span>
                                    </a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e($product->base_price); ?></td>

                                <td data-label="<?php echo app('translator')->get('In Stock'); ?>">
                                    <?php if($product->track_inventory): ?>
                                        <?php echo e(optional($product->stocks)->sum('quantity')); ?>

                                    <?php else: ?>
                                        <?php echo app('translator')->get('Infinite'); ?>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="javascript:void(0)" class="highlight-btn icon-btn btn--success <?php echo e($product->trashed()?'disabled':''); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Highlight'); ?>" data-id="<?php echo e($product->id); ?>" data-featured="<?php echo e($product->is_featured); ?>" data-special="<?php echo e($product->is_special); ?>">
                                        <i class="la la-highlighter"></i>
                                    </a>

                                    <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('admin.products.edit', [$product->id, slug($product->name)])); ?> <?php endif; ?>" class="icon-btn btn--primary <?php echo e($product->trashed()?'disabled':''); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Edit'); ?>">
                                        <i class="la  la-edit"></i>
                                    </a>

                                    <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('admin.products.attribute-add', [$product->id])); ?> <?php endif; ?>" class="icon-btn btn--info text-white <?php echo e($product->trashed()?'disabled':''); ?> <?php echo e($product->has_variants?'':'disabled'); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Add Variants'); ?>">
                                        <i class="la la-palette"></i>
                                    </a>

                                    <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('admin.products.stock.create', [$product->id])); ?> <?php endif; ?>" class="icon-btn btn--warning text-white <?php echo e($product->trashed()?'disabled':''); ?> <?php echo e($product->track_inventory?'':'disabled'); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Manage Inventory'); ?>">
                                        <i class="fas fa-database"></i>
                                    </a>

                                    <button type="button" class="icon-btn btn--<?php echo e($product->trashed()?'success':'danger'); ?> deleteBtn" data-toggle="tooltip" data-title="<?php echo e($product->trashed()?'Restore':'Delete'); ?>" data-type="<?php echo e($product->trashed()?'restore':'delete'); ?>" data-id='<?php echo e($product->id); ?>'>
                                        <i class="la la-<?php echo e($product->trashed()?'redo':'trash'); ?>" ></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($empty_message)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4">
                <nav aria-label="...">
                    <?php echo e($products->appends(['search'=>request()->search ?? null])->links('admin.partials.paginate')); ?>

                </nav>
            </div>

        </div>
    </div>
</div>



<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="" method="POST" id="deleteForm">
            <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title text-capitalize" id="deleteModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-bold">

                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--danger"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="highlight-modal">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Highlight As'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <form action="<?php echo e(route('admin.products.highlight')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id"/>
                <div class="modal-body">
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label class="font-weight-bold">
                                <?php echo app('translator')->get('Featured'); ?>
                            </label>
                        </div>
                        <div class="col-md-8">
                            <label class="switch">
                                <input type="checkbox" name="featured" value="1" >
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-4">
                            <label class="font-weight-bold">
                                <?php echo app('translator')->get('Special'); ?>
                            </label>
                        </div>
                        <div class="col-md-8">
                            <label class="switch">
                                <input type="checkbox" name="special" value="1">
                                <span class="slider round"></span>
                            </label>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">

                    <button type="submit" class="btn btn--success btn-block"><?php echo app('translator')->get('Save'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if(request()->routeIs('admin.products.all')): ?>
    <a href="<?php echo e(route('admin.products.create')); ?>" title="<?php echo app('translator')->get('Shortcut'); ?>: shift+n" class="btn btn-sm btn--success box--shadow1 text--small"><i class="la la-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
    <?php else: ?>
        <?php if(request()->routeIs('admin.products.trashed.search')): ?>
        <a href="<?php echo e(route('admin.products.trashed')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small">
            <i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
        <?php else: ?>
        <a href="<?php echo e(route('admin.products.all')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small">
            <i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(request()->routeIs('admin.products.all')): ?>
    <a href="<?php echo e(route('admin.products.trashed')); ?>" class="btn btn-sm btn--danger box--shadow1 text--small"><i class="la la-trash-alt"></i><?php echo app('translator')->get('Trashed'); ?></a>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<script>

    "use strict";
    (function ($) {

        $(document).keypress(function (e) {
            var unicode = e.charCode ? e.charCode : e.keyCode;
            if(unicode == 78){
                window.location = "<?php echo e(route('admin.products.create')); ?>";
            }
        });

        $('.deleteBtn').on('click', function () {
            var modal   = $('#deleteModal');
            var id      = $(this).data('id');
            var type    = $(this).data('type');
            var form    = document.getElementById('deleteForm');

            if(type == 'delete'){
                modal.find('.modal-title').text('<?php echo e(trans("Delete Product")); ?>');
                modal.find('.modal-body').text('<?php echo e(trans("Are you sure to delete this product?")); ?>');
            }else{
                modal.find('.modal-title').text('<?php echo e(trans("Restore Product")); ?>');
                modal.find('.btn--danger').removeClass('btn--danger').addClass('btn--success');
                modal.find('.modal-body').text('<?php echo e(trans("Are you sure to restore this product?")); ?>');
            }

            form.action = '<?php echo e(route('admin.products.delete', '')); ?>'+'/'+id;
            modal.modal('show');
        });

        $('.image-popup').magnificPopup({
            type: 'image'
        });

        $('.highlight-btn').on('click', function(e){
            var modal       = $('#highlight-modal');
            var id          = $(this).data('id');
            var featured    = $(this).data('featured');
            var special     = $(this).data('special');

            if(featured == 1){
                modal.find('input[name=featured]').prop('checked', true);
            }else{
                modal.find('input[name=featured]').prop('checked', false);
            }

            if(special == 1){
                modal.find('input[name=special]').prop('checked', true);
            }else{
                modal.find('input[name=special]').prop('checked', false);
            }

            modal.find('input[name=product_id]').val(id);
            modal.modal('show');
        });
    })(jQuery)
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/products/index.blade.php ENDPATH**/ ?>