<!-- Section Starts Here -->
<div class="padding-bottom-half padding-top-half oh">
    <div class="container">
        <ul class="nav nav-tabs">
            <?php $__currentLoopData = $f_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a href="#cat-<?php echo e($f_category->id); ?>" class="nav-link <?php if($loop->first): ?> active <?php endif; ?>" data-toggle="tab"><?php echo e(__($f_category->name)); ?></a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="tab-content">
            <?php $__currentLoopData = $f_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="cat-<?php echo e($f_category->id); ?>">
                    <div class="m--15">
                        <div class="row mb-30-none page-main-content">
                            <?php $__currentLoopData = $f_category->specialProuducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if($item->offer && $item->offer->activeOffer){
                                    $discount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                                } else {
                                    $discount = 0;
                                }
                                $wCk = checkWishList($item->id);
                                $cCk = checkCompareList($item->id);
                                ?>
                                <div class="col-lg-3 col-md-4 col-sm-6">
                                    <div class="product-item-2">
                                        <div class="product-item-2-inner wish-buttons-in">
                                            <ul class="wish-react">
                                                <li>
                                                    <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk ? 'active' : ''); ?>" data-id="<?php echo e($item->id); ?>"><i class="lar la-heart"></i></a>
                                                </li>
                                                <li>
                                                    <a href="javascript:void(0)" title="<?php echo app('translator')->get('Compare'); ?>" class="add-to-compare <?php echo e($cCk ? 'active' : ''); ?>" data-id="<?php echo e($item->id); ?>"><i class="las la-sync-alt"></i></a>
                                                </li>
                                            </ul>
                                            <div class="product-thumb">
                                                <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                                                </a>
                                            </div>
                                            <div class="product-content">
                                                <div class="product-before-content">
                                                    <h6 class="title">
                                                        <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                                    </h6>
                                                    <div class="ratings-area justify-content-between">
                                                        <div class="ratings">
                                                            <?php echo __(display_avg_rating($item->reviews)) ?>
                                                        </div>
                                                        <span class="ml-2 mr-auto">(<?php echo e(__($item->reviews->count())); ?>)</span>
                                                        <div class="price">
                                                            <?php if($discount > 0): ?>
                                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                                            <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                                            <?php else: ?>
                                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-after-content">
                                                    <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                                        <?php echo app('translator')->get('View'); ?>
                                                    </button>
                                                    <div class="price">
                                                        <?php if($discount > 0): ?>
                                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                                        <?php else: ?>
                                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Section Ends Here -->
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/sections/filter_categories.blade.php ENDPATH**/ ?>