<?php $__env->startSection('panel'); ?>
    <?php if(@json_decode($general->sys_version)->version > systemDetails()['version']): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card text-white bg-warning mb-3">
                <div class="card-header">
                    <h3 class="card-title"> <?php echo app('translator')->get('New Version Available'); ?> <button class="btn btn--dark float-right"><?php echo app('translator')->get('Version'); ?> <?php echo e(json_decode($general->sys_version)->version); ?></button> </h3>
                </div>
                <div class="card-body">
                    <h5 class="card-title text-dark"><?php echo app('translator')->get('What is the Update ?'); ?></h5>
                    <p><pre  class="f-size--24"><?php echo e(json_decode($general->sys_version)->details); ?></pre></p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php if(@json_decode($general->sys_version)->message): ?>
    <div class="row">
        <?php $__currentLoopData = json_decode($general->sys_version)->message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12">
            <div class="alert border border--primary" role="alert">
                <div class="alert__icon bg--primary"><i class="far fa-bell"></i></div>
                <p class="alert__message"><?php echo $msg; ?></p>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    <div class="row mb-none-30">
        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--dark b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--dark"><i class="las la-cart-arrow-down"></i></div>
                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('All Order'); ?></p>

                    <h1 class="text--dark font-weight-bold">
                        <?php echo e($widget['all_orders']); ?>

                    </h1>
                    <p class="mt-10 text-right">
                        <a class="btn btn-sm btn--dark" href="<?php echo e(route('admin.order.index')); ?>"><?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget end -->
        </div>

        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--teal b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--teal">
                    <i class="las la-shopping-cart"></i>
                </div>
                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('Total Sale'); ?></p>

                    <h1 class="text--teal font-weight-bold">
                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($payment['total_deposit_amount'], 2)); ?>

                    </h1>
                    <p class="mt-10 text-right">
                        <a class="btn btn-sm bg--teal text-white" href="<?php echo e(route('admin.deposit.list')); ?>"><?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget end -->
        </div>

        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--light-blue b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--light-blue">
                    <i class="las la-tshirt"></i>
                </div>
                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('Total Product'); ?></p>
                    <h1 class="text--light-blue font-weight-bold">
                        <?php echo e($widget['total_product']); ?>

                    </h1>
                    <p class="mt-10 text-right">
                        <a class="btn btn-sm bg--light-blue text-white" href="<?php echo e(route('admin.products.all')); ?>"><?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget end -->
        </div>

        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--cyan b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--cyan">
                    <i class="las la-users"></i>
                </div>

                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('Total Customer'); ?></p>
                    <h1 class="text--cyan font-weight-bold"><?php echo e($widget['total_users']); ?></h1>

                    <p class="mt-10 text-right">
                        <a class="btn btn-sm bg--cyan text--white" href="<?php echo e(route('admin.users.all')); ?>">
                            <?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget-two end -->
        </div>


        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--success b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--success">
                    <i class="las la-user-check"></i>
                </div>
                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('Active Customers'); ?></p>
                    <h1 class="text--success font-weight-bold">
                        <?php echo e($widget['verified_users']); ?>

                    </h1>
                    <p class="mt-10 text-right">
                        <a class="btn btn-sm btn--success" href="<?php echo e(route('admin.users.active')); ?>"><?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget end -->
        </div>

        <div class="col-xl-4 col-md-6 mb-30">
            <div class="widget bb--3 border--deep-purple b-radius--10 bg--white p-4 box--shadow2 has--link">
                <div class="widget__icon b-radius--rounded bg--deep-purple">
                    <i class="las la-thumbs-up"></i>
                </div>
                <div class="widget__content">
                    <p class="text-uppercase text-muted"><?php echo app('translator')->get('Total Subscriber'); ?></p>
                    <h1 class="text--deep-purple font-weight-bold">
                        <?php echo e($widget['total_subscribers']); ?>

                    </h1>
                    <p class="mt-10 text-right">
                        <a class="btn btn-sm bg--deep-purple text--white" href="<?php echo e(route('admin.subscriber.index')); ?>"><?php echo app('translator')->get('View All'); ?>
                        </a>
                    </p>
                </div>
            </div><!-- widget end -->
        </div>


        <div class="col-xl-4 mb-30">
            <div class="widget-two box--shadow2 b-radius--5 bg--white">
              <i class="icon-7 overlay-icon text text--11"></i>
              <div class="widget-two__icon b-radius--5 bg--11">
                <i class="las la-money-bill"></i>
              </div>
              <div class="widget-two__content">
                <h2><?php echo e($general->cur_sym); ?><?php echo e(getAmount($widget['last_seven_days'], 2)); ?></h2>
                <p><?php echo app('translator')->get('Sale Amount In Last 7 Days'); ?></p>
              </div>
            </div><!-- widget-two end -->
        </div>

        <div class="col-xl-4 mb-30">
            <div class="widget-two box--shadow2 b-radius--5 bg--white">
              <i class="icon-15 overlay-icon text text--dark"></i>
              <div class="widget-two__icon b-radius--5 bg--15">
                <i class="las la-money-bill"></i>
              </div>
              <div class="widget-two__content">
                <h2><?php echo e($general->cur_sym); ?><?php echo e(getAmount($widget['last_fifteen_days'], 2)); ?></h2>
                <p><?php echo app('translator')->get('Sale Amount In Last 15 Days'); ?></p>
              </div>
            </div><!-- widget-two end -->
        </div>

        <div class="col-xl-4 mb-30">
            <div class="widget-two box--shadow2 b-radius--5 bg--white">
              <i class="icon-30 overlay-icon text text--danger"></i>
              <div class="widget-two__icon b-radius--5 bg--5">
                <i class="las la-money-bill"></i>
              </div>
              <div class="widget-two__content">
                <h2><?php echo e($general->cur_sym); ?><?php echo e(getAmount($widget['last_thirty_days'], 2)); ?></h2>
                <p><?php echo app('translator')->get('Sale Amount In Last 30 Days'); ?></p>
              </div>
            </div><!-- widget-two end -->
        </div>

    </div><!-- row end-->

    <div class="row mt-50 mb-none-30">
        <div class="col-xl-6 col-lg-12 mb-30">
            <div class="card min-height-500">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Monthly Sales Report'); ?></h5>
                    <div id="apex-bar-chart"> </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6 col-lg-12 mb-30">
            <div class="card min-height-500">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Top Selling Products'); ?></h5>
                    <?php $__currentLoopData = $widget['top_selling_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if($item->offer && $item->offer->activeOffer){
                                $discount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                            }else $discount = 0;
                        ?>

                        <div class="d-flex flex-wrap single-product mt-30">
                            <a href="<?php echo e(route('product.details', [$item->id, slug($item->name)])); ?>" data-toggle="tooltip" data-placement="bottom" title="<?php echo app('translator')->get('View As Customer'); ?>" class="col-md-2 text-center"><img src="<?php echo e(getImage(imagePath()['product']['path']. '/thumb_'. @$item->main_image, imagePath()['product']['size'])); ?>" alt="image"></a>

                            <div class="col-md-10 mt-md-0 mt-3">
                                <a href="<?php echo e(route('admin.products.edit', [$item->id, slug($item->name)])); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Edit'); ?>" class="text--blue font-weight-bold d-inline-block mb-2"><?php echo e(__($item->name)); ?></a>
                                <p class="float-right"><?php echo e($item->total); ?> <?php echo app('translator')->get('sales'); ?></p>
                                <p><?php echo e(__(shortDescription($item->summary, 100))); ?></p>
                                <p class="font-weight-bold">

                                    <?php if($discount > 0): ?>
                                        <del><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                        <span class="ml-2"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?></span>
                                    <?php else: ?>
                                        <span class="ml-2"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?></span>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div><!-- media end-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div><!-- row end -->


    <div class="row mb-none-30 mt-5">
        <div class="col-xl-6 col-lg-12 mb-30">
            <div class="card ">
                <div class="card-header">
                    <h6 class="card-title mb-0"><?php echo app('translator')->get('Latest Customers'); ?></h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('User'); ?></th>
                                <th><?php echo app('translator')->get('Username'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?></th>
                                <th><?php echo app('translator')->get('Order'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $latestUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Customer'); ?>">
                                        <div class="user">
                                            <div class="thumb">
                                                <a href="<?php echo e(getAvatar('assets/images/user/profile/'. $user->image)); ?>" class="image-popup">
                                                    <img src="<?php echo e(getAvatar('assets/images/user/profile/'. $user->image)); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                                                </a>
                                            </div>
                                            <span class="name"><?php echo e($user->fullname); ?></span>
                                        </div>
                                    </td>

                                    <td data-label="<?php echo app('translator')->get('Username'); ?>"><a href="<?php echo e(route('admin.users.detail', $user->id)); ?>"><?php echo e($user->username); ?></a></td>
                                    <td data-label="<?php echo app('translator')->get('Email'); ?>"><?php echo e($user->email); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Order'); ?>"><?php echo e($user->orders->count()); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="<?php echo e(route('admin.users.detail', $user->id)); ?>" class="icon-btn" data-toggle="tooltip" data-original-title="<?php echo app('translator')->get('Details'); ?>">
                                            <i class="las la-desktop text--shadow"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('Customer Not Found'); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
            </div><!-- card end -->
        </div>

        <div class="col-xl-6 mb-30">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title mb-0"><?php echo app('translator')->get('Latest Orders'); ?></h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th scope="col"><?php echo app('translator')->get('Customer'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Order Id'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Shipping Charge'); ?></th>
                                    <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Customer'); ?>">
                                        <div class="user">
                                            <div class="thumb">
                                                <a href="<?php echo e(getAvatar('assets/images/user/profile/'. $order->user->image)); ?>" class="image-popup">
                                                    <img src="<?php echo e(getAvatar('assets/images/user/profile/'. $order->user->image)); ?>" alt="image">
                                                </a>
                                            </div>
                                            <span class="name"><?php echo e($order->user->fullname); ?></span>
                                        </div>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Order Id'); ?>"><?php echo e($order->order_number); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>"><?php echo e($order->amount); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Shipping Charge'); ?>"><?php echo e($order->shipping_charge); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.order.details', $order->id)); ?>" class="icon-btn" data-toggle="tooltip" title="" data-original-title="Details">
                                            <i class="las la-desktop text--shadow"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo app('translator')->get('No Order Yet'); ?></td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div><!--card end-->


    </div>

    <div class="row mb-none-30 mt-5">
        <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
            <div class="card overflow-hidden">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By Browser'); ?></h5>
                    <canvas id="userBrowserChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By OS'); ?></h5>
                    <canvas id="userOsChart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-lg-6 col-md-6 mb-30">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo app('translator')->get('Login By Country'); ?></h5>
                    <canvas id="userCountryChart"></canvas>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

    <script src="<?php echo e(asset('assets/admin/js/vendor/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vendor/chart.js.2.8.0.js')); ?>"></script>
    <script>
        "use strict";
        (function($){
            $('.image-popup').magnificPopup({
                type: 'image'
            });
        })(jQuery)
        // apex-bar-chart js
        var options = {
            series: [{
                name: 'Total Sale',
                data: <?php echo json_encode($report['deposit_month_amount']->flatten(), 15, 512) ?>
            }],
            chart: {
                type: 'bar',
                height: 400,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '50%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: <?php echo json_encode($report['months']->flatten(), 15, 512) ?>,
            },
            yaxis: {
                title: {
                    text: "<?php echo e($general->cur_sym); ?>",
                    style: {
                        color: '#7c97bb'
                    }
                }
            },
            grid: {
                xaxis: {
                    lines: {
                        show: false
                    }
                },
                yaxis: {
                    lines: {
                        show: false
                    }
                },
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return "<?php echo e($general->cur_sym); ?>" + val + " "
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#apex-bar-chart"), options);
        chart.render();

        var ctx = document.getElementById('userBrowserChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_browser_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_browser_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#ff7675',
                        '#6c5ce7',
                        '#ffa62b',
                        '#ffeaa7',
                        '#D980FA',
                        '#fccbcb',
                        '#45aaf2',
                        '#05dfd7',
                        '#FF00F6',
                        '#1e90ff',
                        '#2ed573',
                        '#eccc68',
                        '#ff5200',
                        '#cd84f1',
                        '#7efff5',
                        '#7158e2',
                        '#fff200',
                        '#ff9ff3',
                        '#08ffc8',
                        '#3742fa',
                        '#1089ff',
                        '#70FF61',
                        '#bf9fee',
                        '#574b90'
                    ],
                    borderColor: [
                        'rgba(231, 80, 90, 0.75)'
                    ],
                    borderWidth: 0,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                maintainAspectRatio: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            }
        });

        var ctx = document.getElementById('userOsChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_os_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_os_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#ff7675',
                        '#6c5ce7',
                        '#ffa62b',
                        '#ffeaa7',
                        '#D980FA',
                        '#fccbcb',
                        '#45aaf2',
                        '#05dfd7',
                        '#FF00F6',
                        '#1e90ff',
                        '#2ed573',
                        '#eccc68',
                        '#ff5200',
                        '#cd84f1',
                        '#7efff5',
                        '#7158e2',
                        '#fff200',
                        '#ff9ff3',
                        '#08ffc8',
                        '#3742fa',
                        '#1089ff',
                        '#70FF61',
                        '#bf9fee',
                        '#574b90'
                    ],
                    borderColor: [
                        'rgba(0, 0, 0, 0.05)'
                    ],
                    borderWidth: 0,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            },
        });


        // Donut chart
        var ctx = document.getElementById('userCountryChart');
        var myChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($chart['user_country_counter']->keys(), 15, 512) ?>,
                datasets: [{
                    data: <?php echo e($chart['user_country_counter']->flatten()); ?>,
                    backgroundColor: [
                        '#ff7675',
                        '#6c5ce7',
                        '#ffa62b',
                        '#ffeaa7',
                        '#D980FA',
                        '#fccbcb',
                        '#45aaf2',
                        '#05dfd7',
                        '#FF00F6',
                        '#1e90ff',
                        '#2ed573',
                        '#eccc68',
                        '#ff5200',
                        '#cd84f1',
                        '#7efff5',
                        '#7158e2',
                        '#fff200',
                        '#ff9ff3',
                        '#08ffc8',
                        '#3742fa',
                        '#1089ff',
                        '#70FF61',
                        '#bf9fee',
                        '#574b90'
                    ],
                    borderColor: [
                        'rgba(231, 80, 90, 0.75)'
                    ],
                    borderWidth: 0,

                }]
            },
            options: {
                aspectRatio: 1,
                responsive: true,
                elements: {
                    line: {
                        tension: 0 // disables bezier curves
                    }
                },
                scales: {
                    xAxes: [{
                        display: false
                    }],
                    yAxes: [{
                        display: false
                    }]
                },
                legend: {
                    display: false,
                }
            }
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>