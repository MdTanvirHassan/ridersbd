<?php
    $sliders = getContent('sliders.element');
?>

<style>
    .image-container {   
        width: 100vw !important;  
        /* height: 350px!important; */
        overflow: hidden; 
    }

    .image-container img {
        width: 50vw!important;
        height: 70vh!important;
        object-fit: fill!important; 
    }
    .banner-section,.banner-slider ,.owl-theme ,.owl-carousel {
        padding: 0;
        margin: 0;
        overflow: hidden;
    }
    .owl-item{
        width: 35vw!important;
        height: 70vh!important;
        object-fit: fill !important;
        padding: 0%!important;
    }
</style>

<?php if($sliders && $sliders->count() > 0): ?>
<div class="banner-section oh rounded--5 mb-30 justify-content-center align-items-center" >
    <div class="banner-slider owl-theme owl-carousel">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(@$slider->data_values->link); ?>" class="d-block" >
            <div class="slide-item image-container">
                    <img src="<?php echo e(getImage('assets/images/frontend/sliders/'. @$slider->data_values->slider, '1220x750')); ?>" alt="<?php echo app('translator')->get('slider'); ?>"  class="image-size">
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="slide-progress"></div>
</div>
<?php endif; ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/sections/sliders.blade.php ENDPATH**/ ?>