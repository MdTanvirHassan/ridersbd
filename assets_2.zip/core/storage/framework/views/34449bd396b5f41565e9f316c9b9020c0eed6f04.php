<div class="sidebar capsule--rounded bg_img overlay--dark" data-background="<?php echo e(getImage('assets/admin/images/sidebar/2.jpg','400x800')); ?>"
     >
    <button class="res-sidebar-close-btn"><i class="las la-times"></i></button>
    <div class="sidebar__inner">
        <div class="sidebar__logo">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar__main-logo"><img
                    src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo_2.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>"></a>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar__logo-shape"><img
                    src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>"></a>
            <button type="button" class="navbar__expand"></button>
        </div>

        <div class="sidebar__menu-wrapper" id="sidebar__menuWrapper">
            <ul class="sidebar__menu">

                <li class="sidebar-menu-item <?php echo e(menuActive('admin.dashboard')); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link ">
                        <i class="menu-icon las la-home"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Dashboard'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.users*',3)); ?>">
                        <i class="menu-icon las la-users"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Customers'); ?></span>

                        <?php if($banned_users_count > 0 || $email_unverified_users_count > 0 || $sms_unverified_users_count > 0): ?>
                            <span class="menu-badge pill bg--primary ml-auto">
                                <i class="fa fa-exclamation"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.users*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.all')); ?> ">
                                <a href="<?php echo e(route('admin.users.all')); ?>" class="nav-link">
                                    <i class="menu-icon las la-user-friends"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Customer'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.active')); ?> ">
                                <a href="<?php echo e(route('admin.users.active')); ?>" class="nav-link">
                                    <i class="menu-icon las la-user-check"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Active Customers'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.banned')); ?> ">
                                <a href="<?php echo e(route('admin.users.banned')); ?>" class="nav-link">
                                    <i class="menu-icon las la-user-times"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Banned Customers'); ?></span>
                                    <?php if($banned_users_count): ?>
                                        <span class="menu-badge pill bg--primary ml-auto"><?php echo e($banned_users_count); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item  <?php echo e(menuActive('admin.users.emailUnverified')); ?>">
                                <a href="<?php echo e(route('admin.users.emailUnverified')); ?>" class="nav-link">
                                    <i class="menu-icon las la-user-alt-slash"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Email Unverified'); ?></span>

                                    <?php if($email_unverified_users_count): ?>
                                        <span
                                            class="menu-badge pill bg--primary ml-auto"><?php echo e($email_unverified_users_count); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.smsUnverified')); ?>">
                                <a href="<?php echo e(route('admin.users.smsUnverified')); ?>" class="nav-link">
                                    <i class="menu-icon las la-user-alt-slash"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('SMS Unverified'); ?></span>
                                    <?php if($sms_unverified_users_count): ?>
                                        <span
                                            class="menu-badge pill bg--primary ml-auto"><?php echo e($sms_unverified_users_count); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.login.history')); ?>">
                                <a href="<?php echo e(route('admin.users.login.history')); ?>" class="nav-link">
                                    <i class="menu-icon las la-history"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Login History'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.users.email.all')); ?>">
                                <a href="<?php echo e(route('admin.users.email.all')); ?>" class="nav-link">
                                    <i class="menu-icon las la-envelope"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Send Email'); ?></span>
                                </a>
                            </li>

                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive(['admin.product*', 'admin.category.*', 'admin.subcategory.*', 'admin.attributes*', 'admin.brand.*'], 3)); ?>">
                        <i class="la la-product-hunt menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Product'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive(['admin.product*', 'admin.category.*', 'admin.subcategory.*', 'admin.attributes*', 'admin.brand.*'], 2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.category.*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.category.all')); ?>">
                                    <i class="las la-align-left menu-icon"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Categories'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.brand.*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.brand.all')); ?>">
                                    <i class="la la-tags menu-icon"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Brands'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.attributes*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.attributes')); ?>">
                                    <i class="la la-palette menu-icon"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Attribute Types'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.products.*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.products.all')); ?>">
                                    <i class="menu-icon las la-tshirt"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Products'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.product.review*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.product.reviews')); ?>">
                                    <i class="menu-icon las la-star"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Product Reviews'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.product.query')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.product.query')); ?>">
                                    <i class="menu-icon las la-star"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Product Query'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive(['admin.coupon*', 'admin.offer.*', 'admin.subscriber.*' ], 3)); ?>">
                        <i class="la la-bullhorn menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Promotion'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive(['admin.coupon*', 'admin.offer.*', 'admin.subscriber.*'], 2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.coupon*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.coupon.index')); ?>">
                                    <i class="menu-icon lab la-contao"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Coupons'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.offer*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.offer.index')); ?>">
                                    <i class="menu-icon la la-fire-alt"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Offers'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item  <?php echo e(menuActive('admin.subscriber.index')); ?>">
                                <a href="<?php echo e(route('admin.subscriber.index')); ?>" class="nav-link"
                                data-default-url="<?php echo e(route('admin.subscriber.index')); ?>">
                                    <i class="menu-icon la la-thumbs-up"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Subscribers'); ?> </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive(['admin.deposit.pending', 'admin.deposit.approved', 'admin.deposit.successful', 'admin.deposit.rejected', 'admin.deposit.list*', 'admin.deposit.search'],3)); ?>">
                        <i class="menu-icon las la-credit-card"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Payments'); ?></span>
                        <?php if(0 < $pending_deposits_count): ?>
                            <span class="menu-badge pill bg--primary ml-auto">
                                <i class="fa fa-exclamation"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive(['admin.deposit.pending', 'admin.deposit.approved', 'admin.deposit.successful', 'admin.deposit.rejected', 'admin.deposit.list*', 'admin.deposit.search'],2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.list')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.list')); ?>" class="nav-link">
                                    <i class="menu-icon las la-list-ul"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Payments'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.pending')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.pending')); ?>" class="nav-link">
                                    <i class="menu-icon las la-pause-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Pending Payments'); ?></span>
                                    <?php if($pending_deposits_count): ?>
                                        <span class="menu-badge pill bg--primary ml-auto"><?php echo e($pending_deposits_count); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.approved')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.approved')); ?>" class="nav-link">
                                    <i class="menu-icon las la-check-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Approved Payments'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.successful')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.successful')); ?>" class="nav-link">
                                    <i class="menu-icon las la-check-double"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Successful Payments'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.rejected')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.rejected')); ?>" class="nav-link">
                                    <i class="menu-icon las la-times-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Rejected Payments'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.order*',3)); ?>">
                        <i class="las la-money-bill menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Orders'); ?></span>
                        <?php if($pending_orders_count > 0 || $processing_orders_count || $dispatched_orders_count > 0): ?>
                        <span class="menu-badge pill bg--primary ml-auto">
                            <i class="las la-bell"></i>
                        </span>
                        <?php endif; ?>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.order*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.index')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.index')); ?>">
                                    <i class="menu-icon las la-list-ol"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Orders'); ?></span>

                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.to_deliver')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.to_deliver')); ?>">
                                    <i class="menu-icon las la-pause-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Pending Orders'); ?></span>
                                    <?php if($pending_orders_count > 0): ?>
                                    <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.on_processing')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.on_processing')); ?>">
                                    <i class="menu-icon las la-spinner"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Processing Orders'); ?></span>
                                    <?php if($processing_orders_count > 0): ?>
                                    <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.dispatched')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.dispatched')); ?>">
                                    <i class="menu-icon las la-shopping-basket"></i>

                                    <span class="menu-title"><?php echo app('translator')->get('Dispatched Orders'); ?></span>

                                    <?php if($dispatched_orders_count > 0): ?>
                                    <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.delivered')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.delivered')); ?>">
                                    <i class="menu-icon las la-check-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Delivered Orders'); ?> </span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.canceled')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.canceled')); ?>">
                                    <i class="menu-icon las la-times-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Canceled Orders'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.order.cod')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.order.cod')); ?>">
                                    <i class="menu-icon las la-hand-holding-usd"></i>
                                    <span class="menu-title"><abbr data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>"><?php echo e(@$deposit->gateway->name??trans('COD')); ?></abbr> <?php echo app('translator')->get('Orders'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>


                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.ticket*',3)); ?>">
                        <i class="menu-icon la la-ticket"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Support Ticket'); ?> </span>
                        <?php if(0 < $pending_ticket_count): ?>
                            <span class="menu-badge pill bg--primary ml-auto">
                                <i class="fa fa-exclamation"></i>
                            </span>
                        <?php endif; ?>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.ticket*',2)); ?> ">
                        <ul>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.ticket')); ?> ">
                                <a href="<?php echo e(route('admin.ticket')); ?>" class="nav-link">
                                    <i class="menu-icon las la-list"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Ticket'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.ticket.pending')); ?> ">
                                <a href="<?php echo e(route('admin.ticket.pending')); ?>" class="nav-link">
                                    <i class="menu-icon las la-pause-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Pending Ticket'); ?></span>
                                    <?php if($pending_ticket_count): ?>
                                        <span
                                            class="menu-badge pill bg--primary ml-auto"><?php echo e($pending_ticket_count); ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.ticket.closed')); ?> ">
                                <a href="<?php echo e(route('admin.ticket.closed')); ?>" class="nav-link">
                                    <i class="menu-icon las la-times-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Closed Ticket'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.ticket.answered')); ?> ">
                                <a href="<?php echo e(route('admin.ticket.answered')); ?>" class="nav-link">
                                    <i class="menu-icon las la-reply"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Answered Ticket'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>


                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.report*',3)); ?>">
                        <i class="menu-icon la la-list"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Report'); ?> </span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.report*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive(['admin.report.transaction*'])); ?>">
                                <a href="<?php echo e(route('admin.report.transaction')); ?>" class="nav-link">
                                    <i class="menu-icon las la-money-check"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Transaction Log'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.report.order*')); ?>">
                                <a class="nav-link" href="<?php echo e(route('admin.report.order')); ?>">
                                    <i class="menu-icon las la-cart-arrow-down"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Order Log'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar__menu-header"><?php echo app('translator')->get('Store Front'); ?></li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.frontend.sections*',3)); ?>">
                        <i class="menu-icon la la-html5"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Manage Contents'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.frontend.sections*',2)); ?> ">
                        <ul>
                            <?php
                            $lastSegment =  collect(request()->segments())->last();
                            ?>
                            <?php $__currentLoopData = getPageSections(true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $secs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($secs['builder']): ?>
                                    <li class="sidebar-menu-item  <?php if($lastSegment == $k): ?> active <?php endif; ?> ">
                                        <a href="<?php echo e(route('admin.frontend.sections',$k)); ?>" class="nav-link">
                                            <i class="menu-icon las la-dot-circle"></i>
                                            <span class="menu-title"><?php echo e($secs['name']); ?></span>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('admin.seo')); ?>">
                    <a href="<?php echo e(route('admin.seo')); ?>" class="nav-link">
                        <i class="menu-icon las la-globe"></i>
                        <span class="menu-title"><?php echo app('translator')->get('SEO'); ?></span>
                    </a>
                </li>

                <li class="sidebar__menu-header"><?php echo app('translator')->get('System'); ?></li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive(['admin.deposit.manual.*', 'admin.deposit.gateway.*'],3)); ?>">
                        <i class="menu-icon la la-paypal"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Gateways'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive(['admin.deposit.manual.*', 'admin.deposit.gateway.*'],2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.gateway.*')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.gateway.index')); ?>" class="nav-link">
                                    <i class="menu-icon lab la-amazon-pay"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Automatic Gateways'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.deposit.manual.*')); ?> ">
                                <a href="<?php echo e(route('admin.deposit.manual.index')); ?>" class="nav-link">
                                    <i class="menu-icon las la-money-bill"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Manual Gateways'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>

                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('admin.shipping-methods*')); ?>">
                    <a href="<?php echo e(route('admin.shipping-methods.all')); ?>" class="nav-link">
                        <i class="fas fa-shipping-fast menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Shipping Methods'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive(['admin.setting*', 'admin.language*', 'admin.plugin*'],3)); ?>">
                        <i class="menu-icon la la-tools"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Settings'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive(['admin.setting*', 'admin.language*', 'admin.plugin*'],2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.setting.index')); ?>">
                                <a href="<?php echo e(route('admin.setting.index')); ?>" class="nav-link">
                                    <i class="menu-icon las la-life-ring"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Genreal'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.setting.logo-icon')); ?>">
                                <a href="<?php echo e(route('admin.setting.logo-icon')); ?>" class="nav-link">
                                    <i class="menu-icon las la-images"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Logos & Favicon'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item  <?php echo e(menuActive(['admin.language-manage','admin.language-key'])); ?>">
                                <a href="<?php echo e(route('admin.language-manage')); ?>" class="nav-link"
                                   data-default-url="<?php echo e(route('admin.language-manage')); ?>">
                                    <i class="menu-icon las la-language"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Language'); ?> </span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.plugin.index')); ?>">
                                <a href="<?php echo e(route('admin.plugin.index')); ?>" class="nav-link">
                                    <i class="menu-icon las la-cogs"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Plugins'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>


                <li class="sidebar__menu-header"><?php echo app('translator')->get('Notification'); ?></li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.email_template*',3)); ?>">
                        <i class="menu-icon la la-envelope-o"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Email'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.email-template*',2)); ?> ">
                        <ul>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.email_template.global')); ?> ">
                                <a href="<?php echo e(route('admin.email_template.global')); ?>" class="nav-link">
                                    <i class="menu-icon las la-envelope-open-text"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Global Template'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive(['admin.email-template.index','admin.email-template.edit'])); ?> ">
                                <a href="<?php echo e(route('admin.email-template.index')); ?>" class="nav-link">
                                    <i class="menu-icon las la-envelope-open"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Email Templates'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.email-template.setting')); ?> ">
                                <a href="<?php echo e(route('admin.email-template.setting')); ?>" class="nav-link">
                                    <i class="menu-icon las la-at"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Email Configure'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('admin.sms-template*',3)); ?>">
                        <i class="menu-icon la la-mobile"></i>
                        <span class="menu-title"><?php echo app('translator')->get('SMS'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('admin.sms-template*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('admin.sms-template.global')); ?> ">
                                <a href="<?php echo e(route('admin.sms-template.global')); ?>" class="nav-link">
                                    <i class="menu-icon las la-database"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('API Setting'); ?></span>
                                </a>
                            </li>
                            <li class="sidebar-menu-item <?php echo e(menuActive(['admin.sms-template.index','admin.sms-template.edit'])); ?> ">
                                <a href="<?php echo e(route('admin.sms-template.index')); ?>" class="nav-link">
                                    <i class="menu-icon las la-sms"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('SMS Templates'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="sidebar__menu-header"><?php echo app('translator')->get('Others'); ?></li>
                <li class="sidebar-menu-item <?php echo e(menuActive('clear-cache')); ?> ">
                    <a href="<?php echo e(route('clear-cache')); ?>" class="nav-link">
                        <i class="menu-icon las la-history"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Clear Cache'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item mt-2">
                    <div class="nav-link d-flex justify-content-center">
                        <span>
                            <span class="text--primary font-weight-bold"><?php echo e(systemDetails()['name']); ?></span>
                            <span class="text--success"><?php echo app('translator')->get('V'); ?><?php echo e(systemDetails()['version']); ?> </span>
                        </span>
                    </div>
                </li>
            </ul>


        </div>
    </div>
</div>
<!-- sidebar end -->
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/partials/sidenav.blade.php ENDPATH**/ ?>