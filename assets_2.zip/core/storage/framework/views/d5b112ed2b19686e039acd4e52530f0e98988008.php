<?php $__env->startSection('panel'); ?>


<div class="row justify-content-center">

    <div class="loader-container text-center d-none">
        <span class="loader">
            <i class="fa fa-circle-notch fa-spin" aria-hidden="true"></i>
        </span>
    </div>

    <div class="col-lg-12">
        <form action="<?php echo e(route('admin.products.product-store', isset($product)?$product->id:0)); ?>" id="addForm" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card p-2 has-select2">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Product Information'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Product Name'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." value="<?php echo e(isset($product)?$product->name:old('name')); ?>" name="name" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Product Model'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." value="<?php echo e(isset($product)?$product->model:old('model')); ?>" name="model" />
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Brand'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control select2-basic" name="brand_id" required>
                                <option disabled value=""><?php echo app('translator')->get('Select One'); ?></option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option selected value="<?php echo e(@$brand->id); ?>" <?php echo e(isset($product)?($brand->id==$product->brand_id?'selected':''):''); ?>>
                                    <?php echo e(__($brand->name)); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-lg-2 col-md-3">
                            <label class="font-weight-bold" for="categories"><?php echo app('translator')->get('Categories'); ?></label>
                        </div>
                        <div class="col-lg-10 col-md-9">
                            <select class="select2-multi-select form-control" name="categories[]" id="categories" multiple required">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo app('translator')->get($category->name); ?></option>
                                    <?php
                                        $prefix = '--'
                                    ?>
                                    <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('admin.partials.subcategories', ['subcategory' => $subcategory, 'prefix'=>$prefix], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <option value="<?php echo e($subcategory->id); ?>">
                                            <?php echo e($prefix); ?><?php echo app('translator')->get($subcategory->name); ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Base Price'); ?></label>
                        </div>
                        <div class="col-md-10">

                            <div class="input-group">
                                <input type="text" class="form-control numeric-validation" name="base_price" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." value="<?php echo e($product->base_price??0); ?>" required/>
                                <div class="input-group-append">
                                    <span class="input-group-text"><?php echo app('translator')->get($general->cur_sym); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Product Description'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Summary'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <textarea rows="5" class="form-control nicEdit" name="summary"><?php echo e($product->summary??''); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Description'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <textarea rows="5" class="form-control nicEdit" name="description"><?php echo ($product->description)??'' ?></textarea>
                        </div>
                    </div>
                    
                </div>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Extra Descriptions'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="extras">
                        <?php if(isset($product) && $product->extra_descriptions != null): ?>
                            <?php $__currentLoopData = $product->extra_descriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="extra">
                                    <div class="d-flex justify-content-end mb-3">
                                        <button type="button" class="btn btn-outline--danger float-right  remove-extra"><i class="la la-minus"></i></button>
                                    </div>

                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Name'); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <input type="text" class="form-control" name="extra[<?php echo e($loop->iteration); ?>][key]" value="<?php echo e($item['key']); ?>">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Value'); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <textarea class="form-control nicEdit" name="extra[<?php echo e($loop->iteration); ?>][value]" rows="3"> <?php echo $item['value'] ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-md-8">
                            <p class="p-2 extra-info"><?php echo app('translator')->get('Add more descriptions as you want by clicking the (+) button on the right side.'); ?></p>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex justify-content-end">

                                <button type="button" class="btn btn-outline--success add-extra"><i class="la la-plus"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Inventory'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold">
                                <?php echo app('translator')->get('Track Inventory'); ?>
                            </label>
                        </div>
                        <div class="col-md-10">
                            <label class="switch">
                                <input type="checkbox" name="track_inventory" value="1" <?php if(isset($product)): ?> <?php echo e(@$product->track_inventory?'checked':''); ?> <?php else: ?> checked  <?php endif; ?>>
                                <span class="slider round"></span>
                            </label>

                        </div>

                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold">
                                <?php echo app('translator')->get('Show in Frontend'); ?>
                            </label>
                        </div>
                        <div class="col-md-10">
                            <label class="switch">
                                <input type="checkbox" name="show_in_frontend" value="1" <?php if(isset($product)): ?> <?php echo e(@$product->show_in_frontend?'checked':''); ?> <?php else: ?> checked  <?php endif; ?>>
                                <span class="slider round"></span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold">
                                <?php echo app('translator')->get('Has Variants'); ?>
                            </label>
                        </div>
                        <div class="col-md-10">
                            <label class="switch">
                                <input type="checkbox" name="has_variants" value="1" <?php if(isset($product)): ?> <?php echo e($product->has_variants?'checked':''); ?>  <?php endif; ?>>
                                <span class="slider round"></span>
                            </label>

                        </div>
                    </div>

                    <div class="form-group row sku-wrapper">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Product SKU'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." value="<?php echo e(isset($product)?$product->sku:old('sku')); ?>" name="sku" />
                        </div>
                    </div>
                </div>
                <?php if(request()->routeIs('admin.products.edit')): ?>
                <div class="card-footer">
                    <h5 class="ml-3 text-danger font-weight-bold"><?php echo app('translator')->get('If you change the value of Track Inventory or Has Variants, your previous stock records for this product will be removed.'); ?></h5>
                </div>
                <?php endif; ?>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Product Specifications'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="specifications-wrapper">
                        <?php if(isset($product) && $product->specification != null): ?>
                            <?php $__currentLoopData = $product->specification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="specifications">
                                <div class="row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold"><?php echo e($loop->iteration); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="specification[<?php echo e($loop->iteration); ?>][name]" placeholder="<?php echo app('translator')->get('Type Name Here...'); ?>" value="<?php echo e(@$item['name']); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group abs-form-group d-flex justify-content-between flex-wrap">

                                                    <input type="text" class="form-control" name="specification[<?php echo e($loop->iteration); ?>][value]" placeholder="<?php echo app('translator')->get('Type Value Here...'); ?>" value="<?php echo e(@$item['value']); ?>"">
                                                    <button type="button" class="btn btn-outline--danger remove-specification abs-button"><i class="la la-minus"></i></button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <p class="p-2 specification-info"><?php echo app('translator')->get('Add specifications as you want by clicking the (+) button on the right side.'); ?></p>
                        </div>

                        <div class="col-md-4">
                            <div class="d-flex justify-content-end">
                                <button type="button" class="btn btn-outline--success add-specification "><i class="la la-plus"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('SEO Contents'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Meta Title'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" name="meta_title" value="<?php echo e(isset($product)?$product->meta_title:old('meta_title')); ?>" placeholder="<?php echo app('translator')->get('Meta Title'); ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Meta Description'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <textarea name="meta_description" rows="5" class="form-control"><?php echo e(isset($product)?$product->meta_description:old('meta_description')); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Meta Keywords'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <select name="meta_keywords[]" class="form-control select2-auto-tokenize"  multiple="multiple">
                                <?php if(@$product->meta_keywords): ?>
                                    <?php $__currentLoopData = $product->meta_keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option); ?>" selected><?php echo e(__($option)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                            <small class="form-text text-muted">
                                <i class="las la-info-circle"></i>
                                <?php echo app('translator')->get('Type , as seperator or hit enter among keywords'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card p-2 my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Media Contents'); ?></h5>
                </div>
                <div class="card-body">

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Main Image'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <div class="payment-method-item">
                                <div class="payment-method-header d-flex flex-wrap">
                                    <div class="thumb">
                                        <div class="avatar-preview">
                                            <div class="profilePicPreview" style="background-image: url('<?php echo e(getImage(imagePath()['product']['path'].'/'.@$product->main_image, imagePath()['product']['size'])); ?>')"></div>
                                        </div>
                                        <div class="avatar-edit">
                                            <input type="file" name="main_image" class="profilePicUpload" id="image" accept=".png, .jpg, .jpeg" <?php if(request()->routeIs('admin.products.create')): ?>required <?php endif; ?>>
                                            <label for="image" class="bg--primary"><i class="la la-pencil"></i></label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Additional Images'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <div class="input-field">
                                <div class="input-images"></div>
                                <small class="form-text text-muted">
                                    <i class="las la-info-circle"></i> <?php echo app('translator')->get('You can only upload a maximum of 6 images'); ?></label>
                                </small>
                            </div>
                        </div>
                    </div>


                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Video'); ?></label>
                        </div>
                        <div class="col-md-10">
                            <input type="text" class="form-control" name="video_link" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." value="<?php echo e($product->video_link??''); ?>" />
                            <small class="form-text text-muted">
                                <i class="las la-info-circle"></i>
                                <?php echo app('translator')->get('Only youtube embed link is allowed'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-block btn--success mt-3"><?php echo e(isset($product)?trans('Update'):trans('Add')); ?></button>
        </form>
    </div>
</div>

<div class="modal fade" id="errorModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <button type="button" class="close ml-auto m-3" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body text-center">
                <i class="las la-times-circle f-size--100 text--danger mb-15"></i>
                <h3 class="text--danger mb-15"><?php echo app('translator')->get('Error: Cannot process your entry!'); ?></h3>
                <p class="mb-15"><?php echo app('translator')->get('You can\'t add more than 6 image'); ?></p>
                <button type="button" class="btn btn--danger" data-dismiss="modal"><?php echo app('translator')->get('Continue'); ?></button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.products.all')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small"><i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/admin/js/image-uploader.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
<link href="https://fonts.googleapis.com/css?family=Lato:300,700|Montserrat:300,400,500,600,700|Source+Code+Pro&display=swap"
rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/image-uploader.min.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>

<script>

    'use strict';
    (function($){
        var dropdownParent = $('.has-select2');

        <?php if(isset($images)): ?>
            let preloaded = <?php echo json_encode($images, 15, 512) ?>;
        <?php else: ?>
            let preloaded = [];
        <?php endif; ?>

        $('.input-images').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'photos',
            preloadedInputName: 'old',
            maxFiles: 6
        });

        $(document).on('input', 'input[name="images[]"]', function(){
            var fileUpload = $("input[type='file']");
            if (parseInt(fileUpload.get(0).files.length) > 6){
                $('#errorModal').modal('show');
            }
        });

        $('select[name="category_id"]').on('change', function () {
            var subcategories = $(this).find(':selected').data('subcats');
            var output= `<div class="col-md-2">
                            <label class="font-weight-bold">Subcategory</label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control select2-basic" name="sub_category_id">
                            <option value="" selected disabled><?php echo app('translator')->get('Select One'); ?></option>
                        </div>
                        `;
            if (subcategories.length != 0) {
                $.each(subcategories, function (key, val) {
                    output += `<option value="${val.id}">${val.name}</option>`;
                });
                output += `</select>`
                $('#sub-categories-div').html(output);
            }
        });

        <?php if(request() -> routeIs('admin.products.edit')): ?>

            var categories = [];
            <?php if($product->categories): ?>
            categories = <?php echo json_encode($product->categories->pluck('id'), 15, 512) ?>;
            <?php endif; ?>
            $('#categories').val(categories);
            $('.select2-multi-select').select2({
                dropdownParent: dropdownParent,
                closeOnSelect: false
            });

        <?php endif; ?>

        $('.add-specification').on('click', function(){
            var specifications = $(document).find('.specifications');
            var length         = specifications.length;
            $('.specification-info').addClass('d-none');
            var content =`<div class="specifications">
                                <div class="row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold">${length+1}</label>
                                    </div>
                                    <div class="col-md-10">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" name="specification[${length}][name]" placeholder="<?php echo app('translator')->get('Type Name Here...'); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-8">
                                                <div class="form-group abs-form-group d-flex justify-content-between flex-wrap">

                                                    <input type="text" class="form-control" name="specification[${length}][value]" placeholder="<?php echo app('translator')->get('Type Value Here...'); ?>">
                                                    <button type="button" class="btn btn-outline--danger remove-specification abs-button"><i class="la la-minus"></i></button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>`;

            $(content).appendTo('.specifications-wrapper').hide().slideDown('slow');

            specifications = $(document).find('.specifications');
            length         = specifications.length;

            if(length > 0) {
                $('.remove-specification').removeClass('d-none');
            }else{
                $('.remove-specification').addClass('d-none');
            }
        });

        $(document).on('click', '.remove-specification' ,function(){

            var parent = $(this).parents('.specifications');

            parent.slideUp('slow', function(e){
                this.remove();
            });

        });

        $('.add-extra').on('click', function(){
            var extras         = $(document).find('.extra');
            var length         = extras.length;

            $('.extra-info').addClass('d-none');

            var content =`<div class="extra">
                                    <div class="d-flex justify-content-end mb-3">
                                        <button type="button" class="btn btn-outline--danger float-right  remove-extra"><i class="la la-minus"></i></button>
                                    </div>
                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Name'); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <input type="text" class="form-control" name="extra[${length + 1}][key]" value="">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-md-2">
                                        <label class="font-weight-bold"><?php echo app('translator')->get('Value'); ?></label>
                                    </div>
                                    <div class="col-md-10">
                                        <textarea class="form-control" name="extra[${length + 1}][value]" rows="3"></textarea>
                                    </div>
                                </div>
                            </div>`;


            var elm = $(content).appendTo('.extras').hide().slideDown('slow').find(`textarea[name="extra[${length +1}][value]"]`);
            var curSize = elm.length;

            new nicEditor().panelInstance(elm[0]);

            extras = $(document).find('.extra');
            length         = extras.length;

            if(length != 0) {
                $('.remove-extra').removeClass('d-none');
            }else{
                $('.remove-extra').addClass('d-none');
            }
        });

        $(document).on('click', '.remove-extra' ,function(){

            var parent = $(this).parents('.extra');
            parent.slideUp('slow', function(){
                this.remove();
            });

        });

        $("input[name='base_price']").on('click',function(){
            if($(this).val()==0){
                $(this).val('');
            }
        });

        if($(document).find('input[name="has_variants"]').prop("checked") == true){
            $(document).find('.sku-wrapper').hide();
        }

        $('input[name="has_variants"]').on('click',function(){
            if($(this).prop("checked") == true){
                $('.sku-wrapper').hide('slow');
                $(document).find('input[name="sku"]').val('');

            }
            else if($(this).prop("checked") == false){
                $('.sku-wrapper').show('slow');
                $(document).find('input[name="sku"]').val('');
            }
        });

        $('#addForm').on('submit', function(e){
                var loading = $('.loader-container');
                e.preventDefault();
                loading.removeClass('d-none').fadeIn();
                var url = this.action;
                var formData = new FormData(this);
                var btn     = $(this).find('button[type=submit]')
                btn.attr('disabled', 'disabled');
                $.ajax({
                    url: url,
                    type : "POST",
                    cache: false,
                    contentType : false,
                    processData: false,
                    data: formData,
                    success: function (response) {
                        if(response.status == 'error'){
                            notify('error', response.message);
                        }else{
                            notify('success', response.message);
                        }
                        if(response.reload == true){
                            location.reload();
                        }
                        btn.removeAttr('disabled');
                        loading.fadeOut();
                    }
                });
            });

    })(jQuery)

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/admin/products/create.blade.php ENDPATH**/ ?>