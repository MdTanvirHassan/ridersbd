<li>
    <a href="<?php echo e(route('products.category', ['id'=>$subcategory->id, 'slug'=>slug($subcategory->name)])); ?>">
        <?php echo $subcategory->icon ?> <?php echo e(__($subcategory->name)); ?>

    </a>

    <?php if($subcategory->allSubcategories): ?>
    <div class="cate-icon">
        <i class="las la-angle-down"></i>
    </div>
    <?php if($subcategory->allSubcategories->count() >0): ?>
    <ul class="sub-category">
        <?php $__currentLoopData = $subcategory->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>
    <?php endif; ?>
</li>
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/partials/menu_subcategories.blade.php ENDPATH**/ ?>