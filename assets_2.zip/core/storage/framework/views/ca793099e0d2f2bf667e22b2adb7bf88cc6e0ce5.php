<?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Flash Section Starts Here -->
    <div class="flash-sell-section padding-bottom-half padding-top-half oh">
        <div class="container">
            <div class="section-header-2 left-style">
                <h3 class="title"><?php echo e(__($offer->name)); ?></h3>
                <ul class="countdown" data-countdown="<?php echo e(showDateTime($offer->end_date,'m/d/Y H:i:s')); ?>">
                    <li>
                        <span class="countdown-title"><span class="days">00</span></span>
                        <p class="days_text"><?php echo app('translator')->get('Days'); ?></p>
                    </li>
                    <li>
                        <span class="countdown-title"><span class="hours">00</span></span>
                        <p class="hours_text"><?php echo app('translator')->get('Hours'); ?></p>
                    </li>
                    <li>
                        <span class="countdown-title"><span class="minutes">00</span></span>
                        <p class="minu_text"><?php echo app('translator')->get('Minutes'); ?></p>
                    </li>
                    <li>
                        <span class="countdown-title"><span class="seconds">00</span></span>
                        <p class="seco_text"><?php echo app('translator')->get('Seconds'); ?></p>
                    </li>
                </ul>
            </div>

            <div class="m--15">
                <div class="product-slider-2 owl-carousel owl-theme">

                    <?php $__currentLoopData = $offer->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $discount = calculateDiscount($offer->amount, $offer->discount_type, $item->base_price);

                        $wCk = checkWishList($item->id);
                        $cCk = checkCompareList($item->id);
                    ?>

                    <div class="product-item-2">
                        <div class="product-item-2-inner wish-buttons-in">
                            <ul class="wish-react">
                                <li>
                                   <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="lar la-heart"></i></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" title="<?php echo app('translator')->get('Compare'); ?>" class="add-to-compare <?php echo e($cCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="las la-sync-alt"></i></a>
                                </li>
                            </ul>
                            <div class="product-thumb">
                                <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                                </a>
                            </div>
                            <div class="product-content">
                                <div class="product-before-content">
                                    <h6 class="title">
                                        <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                    </h6>
                                    <div class="ratings-area justify-content-between">
                                        <div class="ratings">
                                            <?php echo __(display_avg_rating($item->reviews)) ?>
                                        </div>

                                        <span class="ml-2 mr-auto">(<?php echo e(__($item->reviews->count())); ?>)</span>
                                        <div class="price">
                                            <?php if($discount > 0): ?>
                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                            <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                            <?php else: ?>
                                            <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="product-after-content">
                                    <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                        <?php echo app('translator')->get('View'); ?>
                                    </button>
                                    <div class="price">
                                        <?php if($discount > 0): ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                        <?php else: ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
    <!-- Flash Section Ends Here -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/sections/offers.blade.php ENDPATH**/ ?>