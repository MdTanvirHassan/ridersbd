<div class="hero-section section-bg py-4">
    <div class="container">
        <ul class="breadcrumb">

            <?php echo $__env->yieldPushContent('breadcrumb-plugins'); ?>

            <li><?php echo app('translator')->get(__($page_title)); ?></li>
           
        </ul>
    </div>
</div>
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/partials/breadcrumb.blade.php ENDPATH**/ ?>