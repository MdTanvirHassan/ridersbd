
    <!-- Header Section Starts Here -->
    <header>
        <div class="header-top bg-3 py-1 border-bottom-1 d-none d-lg-block">
            <div class="container">
                <div class="header-top-wrap d-flex flex-wrap justify-content-between align-items-center">
                    <div class="right-side">
                        <ul>

                            <li><a href="<?php echo e(route('order-track')); ?>"><?php echo app('translator')->get('3/A, Fair Plaza, Level-10 Mirpur-1, Dhaka-1216'); ?></a></li>
                            <li><a href="<?php echo e(route('order-track')); ?>"><?php echo app('translator')->get('info@ridersgroupbd.com'); ?></a></li>
                            <li><a href="<?php echo e(route('order-track')); ?>"><?php echo app('translator')->get('+88 01989 699 314'); ?></a></li>
                        </ul>
                    </div>
                    <div class="left-side">
                        <div class="language_setting">
                            <div class="active_lang ">


                                <?php if(session('lang') == 'en'): ?>

                                <?php
                                    $default = $language->where('code', 'en')->first();
                                ?>

                                    <div class="img">
                                        <img src="<?php echo e(getImage('assets/images/lang' .'/'. $default['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                                    </div>
                                    <span class="text-capitalize"><?php echo app('translator')->get('English'); ?></span>
                                <?php else: ?>
                                    <?php $lang = $language->where('code', session('lang'))->first() ?>
                                    <div class="img">
                                        <img src="<?php echo e(getImage('assets/images/lang' .'/'. $lang['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('country'); ?>">
                                    </div>
                                    <span class="text-capitalize"><?php echo e(__($lang->name)); ?></span>
                                <?php endif; ?>

                                <i class="las la-caret-down"></i>
                            </div>
                            <ul class="language_setting_list">
                                <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lang->code == request()->session()->get('lang')): ?>
                                <?php continue; ?>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('lang', $lang->code)); ?>">
                                        <div class="img">
                                            <img src="<?php echo e(getImage('assets/images/lang' .'/'. $lang['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('country'); ?>">
                                        </div>
                                        <span class="text-capitalize"><?php echo e(__($lang->name)); ?></span>
                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-middle bg-white py-3">
            <div class="container">
                <div class="header-wrapper justify-content-between align-items-center">
                    <div class="logo" class="d-inline">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(getImage('assets/images/logoIcon/logo.png', '183x54')); ?>" alt="<?php echo app('translator')->get('logo'); ?>" >
                            
                        </a>
                    </div>
                    <h2  class="title mr-auto pl-3 d-inline">
				RIDERS Star Group Ltd.			
			    </h2>
                    
                </div>
            </div>
        </div>

        <div class="header-bottom bg-3 py-3">
            <div class="container">
                <div class="header-bottom-wrapper d-flex flex-wrap justify-content-between align-items-center">
                <div class="header-wrapper justify-content-between align-items-center">
                    
                    <ul class="menu ml-auto d-none d-lg-flex">
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                        </li>
                        <li class="view-category d-none d-lg-block ">
                            <a href="javascript:void(0)"><?php echo app('translator')->get('Products'); ?><i class="las la-angle-down"></i></a
                        </li>
                        <li>
                            <a href="<?php echo e(route('about_us')); ?>"><?php echo app('translator')->get('About Us'); ?></a>
                        </li>

                        <!--<li>-->
                        <!--    <a href="<?php echo e(route('brands')); ?>"><?php echo app('translator')->get('Brands'); ?></a>-->
                        <!--</li>-->
                        <li>
                            <a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                        </li>
                    </ul>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                    
                    <form action="<?php echo e(route('product.search')); ?>" method="GET" class="header-search-form ml-auto <?php if(!request()->routeIs('home')): ?> w-100 <?php endif; ?>" >
                        <div class="header-form-group">
                            <input type="text" name="search_key" value="<?php echo e(request()->search_key); ?>" placeholder="<?php echo app('translator')->get('Search'); ?>...">
                            <button type="submit"><i class="las la-search"></i></button>
                        </div>
                        <div class="select-item">
                            <select class="select-bar" name="category_id">
                                <option selected value="0"><?php echo app('translator')->get('All Categories'); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo app('translator')->get($category->name); ?></option>
                                    <?php
                                        $prefix = '--'
                                    ?>
                                    <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make($activeTemplate.'partials.subcategories', ['subcategory' => $subcategory, 'prefix'=>$prefix], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <option value="<?php echo e($subcategory->id); ?>">
                                            <?php echo e($prefix); ?><?php echo app('translator')->get($subcategory->name); ?>
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form>
                    <?php if(request()->routeIs('home')): ?>
                        <div class="right-toggle text-right d-xl-none">
                            <i class="las la-ellipsis-v"></i>
                        </div>
                    <?php endif; ?>
                    
                </div>
                <div class="pos-rel d-none d-lg-block">
                    <div class="left-category single-style">
                        <ul class="categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>">
                                    <?php echo $category->icon ?> <?php echo e($category->name); ?>

                                </a>

                                <div class="cate-icon">
                                    <i class="las la-angle-down"></i>
                                </div>
                                <?php if($category->allSubcategories->count() > 0): ?>
                                <ul class="sub-category">
                                    <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </header>

    <div class="mobile-menu d-lg-none">
        <div class="mobile-menu-header">
            <div class="mobile-menu-close">
                <i class="las la-times"></i>
            </div>
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(getImage('assets/images/logoIcon/logo_2.png', '183x54')); ?>" alt="<?php echo app('translator')->get('logo'); ?>">
                </a>
            </div>
            <div class="language_setting">
                <div class="active_lang cl-white">

                    <?php if(session('lang') == 'en'): ?>

                    <?php
                        $default = $language->where('code', 'en')->first();
                    ?>
                        <div class="img">
                            <img src="<?php echo e(getImage('assets/images/lang' .'/'. $default['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                        </div>
                        <span class="text-capitalize"><?php echo app('translator')->get('English'); ?></span>
                    <?php else: ?>
                        <?php $lang = $language->where('code', session('lang'))->first() ?>
                        <div class="img">
                            <img src="<?php echo e(getImage('assets/images/lang' .'/'. $lang['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('country'); ?>">
                        </div>
                        <span class="text-capitalize"><?php echo e(__($lang->name)); ?></span>
                    <?php endif; ?>
                    <i class="las la-caret-down"></i>
                </div>
                <ul class="language_setting_list">
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($lang->code == request()->session()->get('lang')): ?>
                    <?php continue; ?>
                    <?php endif; ?>

                    <li>
                        <a href="<?php echo e(route('lang', $lang->code)); ?>">
                            <div class="img">
                                <img src="<?php echo e(getImage('assets/images/lang' .'/'. $lang['icon'],'64x64')); ?>" alt="<?php echo app('translator')->get('country'); ?>">
                            </div>
                            <span class="text-capitalize"><?php echo e(__($lang->name)); ?></span>
                        </a>
                    </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <ul class="nav-tabs nav border-0">
            <li>
                <a href="#menu" class="active" data-toggle="tab"><?php echo app('translator')->get('Menu'); ?></a>
            </li>
            <li>
                <a href="#cate" data-toggle="tab"><?php echo app('translator')->get('Category'); ?></a>
            </li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="menu">
                <div class="mobile-menu-body">
                    <ul class="menu mt-4">
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a>
                        </li>

                        <li>
                            <a href="<?php echo e(route('brands')); ?>"><?php echo app('translator')->get('Brands'); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                        </li>
                    </ul>
                </div>
                <div class="quick-links mt-4">
                    <ul>
                        <?php if($pages->count() > 0): ?>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('pages', ['id' => $item->id, 'slug'=> slug($item->data_values->page_title) ])); ?>"><?php echo __($item->data_values->page_title) ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="t ab-pane fade" id="cate">
                <div class="left-category single-style">
                    <ul class="categories">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>">
                                <?php echo $category->icon ?> <?php echo e($category->name); ?>

                            </a>
                            <div class="cate-icon">
                                <i class="las la-angle-down"></i>
                            </div>

                            <?php if($category->allSubcategories->count()>0): ?>
                            <ul class="sub-category">
                                <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- ===========Cart=========== -->
    <div id="body-overlay" class="body-overlay"></div>
    <div class="cart-sidebar-area" id="cart-sidebar-area">
        <div class="top-content">
            <a href="<?php echo e(route('home')); ?>" class="logo">
                <img src="<?php echo e(getImage('assets/images/logoIcon/logo_2.png', '183x54')); ?>" alt="<?php echo app('translator')->get('logo'); ?>">
            </a>
            <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
        </div>
        <div class="bottom-content">
            <div class="cart-products cart--products">


            </div>
        </div>
    </div>
    <!-- ===========Cart End=========== -->

    <!-- ===========Wishlist=========== -->
    <div class="cart-sidebar-area" id="wish-sidebar-area">
        <div class="top-content">
            <a href="<?php echo e(route('home')); ?>" class="logo">
                <img src="<?php echo e(getImage('assets/images/logoIcon/logo_2.png', '183x54')); ?>" alt="<?php echo app('translator')->get('logo'); ?>">
            </a>
            <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
        </div>
        <div class="bottom-content">
            <div class="cart-products wish-products">

            </div>
        </div>
    </div>
    <!-- ===========Wishlist End=========== -->

    <!-- Header Section Ends Here -->
    <div class="dashboard-menu before-login-menu d-flex flex-wrap justify-content-center flex-column">
        <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
        <?php if(auth()->guard()->guest()): ?>
        <div class="login-wrapper py-5 px-4">
            <h4 class="subtitle cl-white"><?php echo app('translator')->get('My Account'); ?></h4>
            <form method="POST" action="<?php echo e(route('user.login')); ?>" class="sign-in-form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="login-username"><?php echo app('translator')->get('Username'); ?></label>
                    <input type="text" class="form-control" name="username" id="login-username" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Username'); ?>">
                </div>
                <div class="form-group">
                    <label for="login-pass"><?php echo app('translator')->get('Password'); ?></label>
                    <input type="password" class="form-control" name="password" id="login-pass" placeholder="********">
                </div>

                <?php $captcha =   getCustomCaptcha('login captcha') ?>

                <?php if($captcha): ?>
                <div class="form-group">
                    <label for="password"><?php echo app('translator')->get('Captcha'); ?></label>
                    <input type="text" class="mb-4" name="captcha" autocomplete="off" placeholder="<?php echo app('translator')->get('Enter The Code Below'); ?>">
                    <?php echo app('translator')->get($captcha); ?>
                </div>
                <?php endif; ?>

                <div class="form-group text-right pt-2">
                    <button type="submit" class="login-button"><?php echo app('translator')->get('Login'); ?></button>
                </div>

                <div class="pt-2 mb-0">
                    <p class="create-accounts">
                        <a href="<?php echo e(route('user.password.request')); ?>" class="mb-2"><?php echo app('translator')->get('Forgot Password'); ?>?</a>
                    </p>
                    <p class="create-accounts">
                        <span><?php echo app('translator')->get('Don\'t have an account'); ?>? <a href="<?php echo e(route('user.register')); ?>" class="link-color"><?php echo app('translator')->get('Create An Account'); ?></a> </span>
                    </p>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <ul class="cl-white">
            <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
        <?php endif; ?>


    </div>
<?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>