<?php $__env->startSection('content'); ?>

    <div class="main-sections oh">

        
        

        <div class="w-100">
            <?php echo $__env->make($activeTemplate.'sections.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make($activeTemplate.'sections.special_categories', ['special_categories' => $special_categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--<?php echo $__env->make($activeTemplate.'sections.banners_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->
        </div>
        
        </div>

    <!--Futured Product-->
    <?php if($featured_products->count()>0): ?>
        <?php echo $__env->make($activeTemplate.'sections.featured_products', ['featured_products'=> $featured_products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php echo $__env->make($activeTemplate.'sections.offers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make($activeTemplate.'sections.banners_middle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php
        $f_categories = $categories->where('in_filter_menu');
    ?>

    <?php if($f_categories->count()> 0): ?>
        <?php echo $__env->make($activeTemplate.'sections.filter_categories', ['f_categories'=> $f_categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if($top_selling_products->count() > 0): ?>
    <?php echo $__env->make($activeTemplate.'sections.top_selling_products', ['products'=> $top_selling_products], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make($activeTemplate.'sections.top_categories_brands', ['top_categories'=> $top_categories, 'top_brands' => $top_brands], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            //ADD TO CART
        $(document).on('click','.subscribe-btn' , function(){
            var email    = $('input[name="email"]').val();

            $.ajax({
                headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",},
                url:"<?php echo e(route('subscribe')); ?>",
                method:"POST",
                data:{email:email},
                success:function(response)
                {
                    if(response.success) {
                        notify('success', response.success);
                    }else{
                        notify('error', response);
                    }
                }
            });

        });
        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>