<?php $__env->startSection('content'); ?>
<!-- Category Section Starts Here -->
<div class="category-section padding-bottom padding-top">
    <div class="container">
        <?php if($products->count() == 0): ?>
            <div class="col-lg-12 mb-30">
                <?php echo $__env->make($activeTemplate.'partials.empty_message', ['message' => __($empty_message)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-xl-3">
                    <aside class="category-sidebar position-relative">
                        <div class="widget d-xl-none">
                            <div class="d-flex justify-content-between">
                                <h5 class="title border-0 pb-0 mb-0"><?php echo app('translator')->get('Filter'); ?></h5>
                                <div class="close-sidebar"><i class="las la-times"></i></div>
                            </div>
                        </div>

                        <div class="widget">
                            <h5 class="title"><?php echo app('translator')->get('Filter by Price'); ?></h5>
                            <div class="widget-body">
                                <div id="slider-range"></div>
                                <div class="price-range">
                                    <label for="amount"><?php echo app('translator')->get('Price'); ?> :</label>
                                    <input type="text" id="amount" readonly>
                                    <input type="hidden" name="min_price" value="<?php echo e($min_price); ?>">
                                    <input type="hidden" name="max_price" value="<?php echo e($max_price); ?>">
                                </div>
                            </div>
                        </div>


                        <?php if(isset($brands) && $brands->count()>0): ?>

                        <div class="widget">
                            <h5 class="title"><?php echo app('translator')->get('Filter by Brand'); ?></h5>

                            <div class="widget-body">
                                <div class="widget-check-group">
                                    <input type="checkbox" value="0" name="brand" id="all-brand" <?php if(in_array(0, $brand)): ?> checked <?php endif; ?>>
                                    <label for="all-brand"><?php echo app('translator')->get('All Brand'); ?></label>
                                </div>

                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="widget-check-group brand-filter">
                                        <input type="checkbox" value="<?php echo e($item->id); ?>" name="brand" id="brand-<?php echo e($loop->iteration); ?>" <?php if(in_array($item->id, $brand)): ?> checked <?php endif; ?>>
                                        <label for="brand-<?php echo e($loop->iteration); ?>" ><?php echo e(__($item->name)); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <?php endif; ?>



                    </aside>
                </div>
                <div class="col-xl-9">

                    <div class="filter-category-header">

                        <div class="fileter-select-item">
                            <div class="select-item product-page-per-view">
                                <select class="select-bar bg-3" name="per_page">
                                    <option value=""><?php echo app('translator')->get('Products Per Page'); ?></option>
                                    <option value="5" <?php echo e(@$perpage == 5?'selected':''); ?>><?php echo app('translator')->get('5 Items Per Page'); ?> </option>
                                    <option value="15" <?php echo e(@$perpage == 15?'selected':''); ?>><?php echo app('translator')->get('15 Items Per Page'); ?> </option>
                                    <option value="30" <?php echo e(@$perpage == 30?'selected':''); ?>><?php echo app('translator')->get('30 Items Per Page'); ?> </option>
                                    <option value="50" <?php echo e(@$perpage == 50?'selected':''); ?>><?php echo app('translator')->get('50 Items Per Page'); ?> </option>
                                    <option value="100" <?php echo e(@$perpage == 100?'selected':''); ?>><?php echo app('translator')->get('100 Items Per Page'); ?> </option>
                                    <option value="200" <?php echo e(@$perpage == 200?'selected':''); ?>><?php echo app('translator')->get('200 Items Per Page'); ?> </option>
                                </select>
                            </div>
                        </div>

                        <div class="fileter-select-item d-none d-lg-block ml-auto align-self-end">

                            <ul class="view-number">
                                <li class="change-grid-to-6">
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                </li>
                                <li class="change-grid-to-4 active">
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                </li>
                                <li class="change-grid-to-3">
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                    <span class="bar"></span>
                                </li>
                            </ul>
                        </div>
                        <div class="fileter-select-item ml-auto ml-lg-0 align-self-end">
                            <ul class="view-style d-flex">
                                <li>
                                    <a href="javascript:void(0)" class="active view-grid-style"><i class="las la-border-all"></i></a>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" class="view-list-style"><i class="las la-list-ul"></i></a>
                                </li>
                            </ul>
                        </div>
                        <div class="fileter-select-item align-self-end d-xl-none pl-0">
                            <div class="filter-in">
                                <i class="las la-filter"></i>
                            </div>
                        </div>
                    </div>

                    <div class="position-relative">
                        <div id="overlay" >
                            <div class="cv-spinner">
                                <span class="spinner"></span>
                            </div>
                        </div>
                        <div class="overlay-2" id="overlay2"></div>
                        <div class="page-main-content">
                            <div class="row mb-30-none page-main-content" id="grid-view">

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if($item->offer && $item->offer->activeOffer){
                                        $discount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                                    }else $discount = 0;
                                    $wCk = checkWishList($item->id);
                                    $cCk = checkCompareList($item->id);
                                ?>

                                <div class="col-lg-4 col-sm-6 grid-control mb-30">
                                    <div class="product-item-2 m-0">
                                        <div class="product-item-2-inner wish-buttons-in">
                                            <div class="product-thumb">
                                                <ul class="wish-react">
                                                    <li>
                                                        <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="lar la-heart"></i></a>
                                                    </li>
                                                    <li>

                                                        <a href="javascript:void(0)" title="<?php echo app('translator')->get('Compare'); ?>" class="add-to-compare <?php echo e($cCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="las la-sync-alt"></i></a>
                                                    </li>
                                                </ul>
                                                <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                                                </a>
                                            </div>
                                            <div class="product-content">
                                                <div class="product-before-content">
                                                    <h6 class="title">
                                                        <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                                    </h6>
                                                    <h6 class="title mt-1">
                                                        <?php echo app('translator')->get('Brand'); ?> : <?php echo e(__($item->brand->name)); ?>

                                                    </h6>
                                                    <div class="single_content">
                                                        <p><?php echo __($item->summary) ?></p>
                                                    </div>
                                                    <div class="ratings-area justify-content-between">
                                                        <div class="ratings">
                                                            <?php echo __(display_avg_rating($item->reviews)) ?>
                                                        </div>
                                                        <span class="ml-2 mr-auto">(<?php echo e(__($item->reviews->count())); ?>)</span>
                                                        <div class="price">
                                                            <?php if($discount > 0): ?>
                                                                <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                                                <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                                            <?php else: ?>
                                                                <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="product-after-content">
                                                    <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                                        <?php echo app('translator')->get('View'); ?>
                                                    </button>
                                                    <div class="price">
                                                        <?php if($discount > 0): ?>
                                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                                        <?php else: ?>
                                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php echo e($products->appends(['perpage'=>@$perpage, 'brand'=>@$brand, 'min'=>@$min, 'max'=>@$max])->links()); ?>

                        </div>
                    </div>

                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<!-- Category Section Ends Here -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', ['seo_contents'=>@$seo_contents], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function($){

            $('select[name=per_page]').val(`<?php echo e($perpage); ?>`);

            $("input[type='checkbox'][name='brand']").on('click',function(){
                var brand = [];
                var min = $('input[name="min_price"]').val();
                var max = $('input[name="max_price"]').val();

                if($('#all-brand').is(':checked')){
                    $("input[type='checkbox'][name='brand']").not(this).prop('checked', false);
                }
                $('.brand-filter input:checked').each(function() {
                    brand.push(parseInt($(this).attr('value')));
                });

                var perpage = $('select[name=per_page]').val();
                var category_id = `<?php echo e($category->id); ?>`;

                getFilteredData(brand, min, max, category_id, perpage);

            });



            function getFilteredData(brand, min=null, max=null, category_id=`<?php echo e($category->id); ?>`, perpage=`<?php echo e($perpage); ?>`){
                $("#overlay, #overlay2").fadeIn(300);
                $.ajax({
                    url: "<?php echo e(route('category.filter', [$category->id, slug($category->name)])); ?>",
                    method: "get",
                    data: {'brand':brand, 'perpage':perpage, 'min':min,  'max':max, 'category_id': category_id},
                    success: function(result){
                        $('.ajax-preloader').addClass('d-none');
                        $('.page-main-content').html(result);

                    }
                }).done(function() {
                    setTimeout(function(){
                        $("#overlay, #overlay2").fadeOut(300);
                    },500);
                });
            }


            $(document).on('change', '.product-page-per-view select', function(){
                var perpage = $(this).val();
                var brand = [];

                var min = $('input[name="min_price"]').val();
                var max = $('input[name="max_price"]').val();

                $('.brand-filter input:checked').each(function() {
                    brand.push(parseInt($(this).attr('value')));
                });
                var category_id = `<?php echo e($category->id); ?>`;

                getFilteredData(brand, min, max, category_id, perpage);
            });

            $( "#slider-range" ).slider({
                range: true,
                min: <?php echo e($min_price); ?>,
                max: <?php echo e($max_price); ?>,
                values: [ <?php echo e($min_price); ?>, <?php echo e($max_price); ?> ],
                slide: function( event, ui ) {
                    $( "#amount" ).val( "<?php echo e($general->cur_sym); ?>" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
                    $('input[name=min_price]').val(ui.values[ 0 ]);
                    $('input[name=max_price]').val(ui.values[ 1 ]);
                },

                change: function(){
                    var brand = [];
                    var min = $('input[name="min_price"]').val();
                    var max = $('input[name="max_price"]').val();

                    $('.brand-filter input:checked').each(function() {
                        brand.push(parseInt($(this).attr('value')));
                    });

                    var perpage = $('select[name=per_page]').val();
                    var category_id = `<?php echo e($category->id); ?>`;
                    getFilteredData(brand, min, max, category_id);
                }

            });

            $( "#amount" ).val( "<?php echo e($general->cur_sym); ?>" + $( "#slider-range" ).slider( "values", 0 ) + " - <?php echo e($general->cur_sym); ?>" + $( "#slider-range" ).slider( "values", 1 ) );

    })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ridersgr/public_html/laravel.ridersgroupbd.com/core/resources/views/templates/basic/products_by_category.blade.php ENDPATH**/ ?>